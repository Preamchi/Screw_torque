function Add_Screw() {
   
    var emp = document.getElementById('emp').value;
    var part_no = document.getElementById('partno_input').value;
    var screw_name = document.getElementById('screwname_input').value;   

    if ((!part_no) || (!screw_name) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Screw_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp,
                Part_no: part_no,
               Screw_name:screw_name,
            
            },
            success: function(result) {
                Swal.fire({
                    width: 400,
                    title: 'Update Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });
                //modal close
                $('#addModal').modal('hide');
                Load_Screw(); 
     }
        });
    }
}
