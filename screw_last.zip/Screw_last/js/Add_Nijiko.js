function Add_Nijiko() {
   
    var employee = document.getElementById('emp').value;
    var nijiko_name = document.getElementById('nijiko_input').value;   
    var station = document.getElementById('station_loop').value;
    var screw = document.getElementById('screw_loop').value;

    if ((!nijiko_name) || (!station)|| (!screw)){
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {

        $.ajax({
            type: "GET",
            url: "ajax/Nijiko_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: employee,
                Nijiko_Name: nijiko_name,
                Station : station,
                Screw : screw,
                

            
            },
            success: function(result) {
                Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });
                  $('#exampleModal').modal('hide');
                  $('.modal-backdrop').remove();
     }
        });
        Load_Nijiko();
    }
}
