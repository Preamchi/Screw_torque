
function Send_ID(e) {

    document.getElementById("id_hold_user").value = e;
    var emp_id = e;

    $.ajax({
        type: "GET",
        url: "ajax/User_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Emp_ID :  emp_id
        },

        success: function(result) {

            const myJson = JSON.parse(result);
            document.getElementById("employee_id").value = myJson.Emp_ID;
            document.getElementById("employee_role").value = myJson.Emp_Role;
            document.getElementById("employee_name").value = myJson.Emp_Name;

        }
    });

   
}


function Update_User() {

    var admin_id = document.getElementById("admin_login").value;
    var employee_id = document.getElementById("employee_id").value; 
    var new_role = document.getElementById("role_value").value;

if ((!new_role) ) {
    Swal.fire({
        width: 400,
        title: 'Select New Role Please!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 2000,


      })
} else {
    $.ajax({
        type: "GET",
        url: "ajax/User_Update.php",
        async: false,
        cache: false,

        data: {
          Admin_ID: admin_id,
          Emp_ID: employee_id,
          New_Role : new_role,

        },
        success: function(result){
            Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              });
            //modal close
            $('#UserEditModal').modal('hide');
            $('.modal-backdrop').remove();
             load_all_view(); 
        }
    });

   
  
}
}