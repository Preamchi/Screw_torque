
 function Send_id(e) {
    document.getElementById("id_hold_channel").value = e;
    var channel_id = e;

console.log(channel_id);
    $.ajax({
        type: "GET",
        url: "ajax/Channel_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Channel_ID : channel_id
        },

        success: function(result) {
            console.log(result);
            const myJson = JSON.parse(result);
            
            document.getElementById("CH_Name").value = myJson.Channel_Name;
            document.getElementById("last_part").value = myJson.Part_No; 
            document.getElementById("last_cart").value = myJson.Cart_Name;
        
          
           
        }
    });

   
}
 
function load_part2() {
  
    $.ajax({
        url: "ajax/Part_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);

            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='part_nep' >";

     cartoptions += "<option>select new...</option>"; 
            for (let x in myJson) {

                var id = myJson[x]['Part_No'];
                cartoptions += "<option value='" + id + "'>" + id + "</option>";
            }
            cartoptions += '</select>';
            document.getElementById("partno_value").innerHTML = cartoptions;
        }
    });
}

function load_cart2() {
    $.ajax({
        url: "ajax/Cart_value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
/*             var last_value = myJson. */
            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='cart_new' >";
                cartoptions += "<option>select new...</option>"; 

            for (let x in myJson) {

                var name = myJson[x]['Cart_Name'];
                cartoptions += "<option value='" + name + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("cart_value").innerHTML = cartoptions;

        }
    });
}

function Updatechannel() {
    var emp = document.getElementById('emp').value;
    var last_id = document.getElementById("id_hold_channel").value; 
    var new_channel = document.getElementById("CH_Name").value;
    var new_partno = document.getElementById("partno_value").value;
    var new_cartname = document.getElementById("cart_value").value; 
/* console.log(emp, new_partno, new_cartname,channel_id,new_channel); */


if ((!new_cartname)  ) {
    alert('กรอกข้อมูลไม่ครบ');
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Channel_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          LastCH_ID: last_id,
          New_PartNo : new_partno,
          New_Cartname : new_cartname,
          New_Channel : new_channel
       
        },
        
        success: function(result) {
        console.log(result);
        }
    });
    alert('Update successfully!!');
    load_all_view();
}
}  