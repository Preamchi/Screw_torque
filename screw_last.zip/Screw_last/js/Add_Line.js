function Add_Line() {
   
    var emp1 = document.getElementById('emp').value;
    var line_name = document.getElementById('linename_input').value;


    if ((!line_name) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Line_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp1,
               Line_name : line_name
      
            },
            success: function(result) {
                Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });

           $('#AddlineModal').modal('hide');
           Load_Line();
     }
        });
        
       
    }
}
