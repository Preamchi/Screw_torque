function Add_Channel() {
   
    var emp = document.getElementById('emp').value;
    var channel_name = document.getElementById('chname_input').value;
    var plc = document.getElementById('plc_input').value;
    var station = document.getElementById('station_loop').value;
    var model = document.getElementById('model_loop').value;


    if ((!plc) || (!station)|| (!channel_name)|| (!model)) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Channel_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp,  
                Channel_Name : channel_name,
                PLC : plc,
                Station : station,
                Model: model
             
      
            },
            success: function(result) {
                Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });
                  
                  $('#addchannelModal').modal('hide');
                  $('.modal-backdrop').remove();
                  Load_Channel();
     }
        });
        
       Load_Channel();
    }
}