
function Send_model(e) {

    document.getElementById("id_model").value = e;
    var model_id = e;


    $.ajax({
        type: "GET",
        url: "ajax/Model_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Model_ID : model_id
        },

        success: function(result) {
            console.log(result); 
            const myJson = JSON.parse(result);
            console.log(myJson.Station);
            document.getElementById("modelname_data").value = myJson.Model;
            document.getElementById("station_data2").value = myJson.Station; 
            document.getElementById("line_data1").value = myJson.Line; 
         
          
           
        }
    });

   
}

function Line_value1() {
    $.ajax({
        url: "ajax/Line_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
          options += "<option value='null'>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Line'];
               options += "<option value='" + id + "'>" +
                    name + "</option>";
            }
           options += '</select>';

            document.getElementById("line_loop1").innerHTML = options;
            
        }
    });
}

function Station_value1() {
    $.ajax({
        url: "ajax/Station_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
           options += "<option value='null'>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Station'];
               options += "<option value='" + id + "'>" +
                    name + "</option>";
            }
            options += '</select>';

            document.getElementById("station_loop1").innerHTML = options;
            
        }
    });
}
 


function Update_Model() {
    var emp = document.getElementById('emp').value;
    var model_id = document.getElementById("id_model").value; 
    var new_model = document.getElementById("modelname_data").value;
    var new_line = document.getElementById("line_loop1").value;
    var new_station = document.getElementById("station_loop1").value; 

console.log(model_id,new_model, new_line, new_station);

if ((!new_model) ) {
    Swal.fire({
        width: 400,
        title: 'Select New Role Please!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 2000,
      })
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Model_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          Model_ID: model_id,
          Model: new_model,
          Station : new_station,
          Line : new_line
       
        },
        success: function(result){
            Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              });
            //modal close
            $('#EditmodelModal').modal('hide');
            $('.modal-backdrop').remove();
            Load_Model(); 
        }
    });
 /*    alert('Update successfully!!');
    load_all_view(); */
}
}  