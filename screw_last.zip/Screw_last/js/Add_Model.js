function Add_Model() {
   
    var emp1 = document.getElementById('emp').value;
    var model_name = document.getElementById('modelname_input').value;
    var station = document.getElementById('station_loop').value;    
    var line = document.getElementById('line_loop').value;

    console.log(station,line);

    if ((!model_name) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Model_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp1,
                Model_name : model_name,
                station_id : station,
                line_id : line 
      
            },
            success: function(result) {
                Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });
           $('#addchannelModal').modal('hide');
           Load_Model();
     }
        });
        
    }
}
