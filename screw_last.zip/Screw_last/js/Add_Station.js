function Add_Station() {
   
    var employee = document.getElementById('emp').value;
    var st_name = document.getElementById('stname_input').value;   
   


    if ((!st_name) ){
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {

        $.ajax({
            type: "GET",
            url: "ajax/Station_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: employee,
                ST_Name : st_name,
    
             

            },
            success: function(result) {
                Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500 
                  });
                  $('#exampleModal').modal('hide');
                  Load_Station();
     }
        });
       
    }
}
