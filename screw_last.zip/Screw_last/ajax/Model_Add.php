<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Model_Name = $_GET[Model_name];
$Station_ID = $_GET[station_id];
$Line_ID = $_GET[line_id];


/* $sql="
INSERT INTO [STT_DB].[IM].[TBL_ScrewDV_Model]
           ([Model_Name]
           ,[Update_By]
           ,[Create_Date]
           ,[Update_Date])
     VALUES('".$Model_Name."','".$Emp_ID."',GETDATE(),GETDATE())";  */

     $sql=" 
     INSERT INTO [STT_DB].[IM].[SCREW_TQ_Model]
     ([Model]
     ,[Station_Id]
     ,[Line_Id]
     ,[Create_Date]
     ,[Create_By]
     ,[Update_Date]
     ,[Update_By])
VALUES ('".$Model_Name."','".$Station_ID."','".$Line_ID."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')";
 $myfunction->exec($sql);

?>