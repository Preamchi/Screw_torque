<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Employee_ID = $_GET[Emp_Login];



$sql = " 
SELECT [Emp_ID]
      ,[Emp_Name]
      ,[Emp_Role]
 FROM [STT_DB].[IM].[TBL_ScrewDV_Pm_User] WHERE Emp_ID = '$Employee_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_user = $val;
}

 $get_user = json_encode($data_user);
    echo  $get_user;

    
 
?>