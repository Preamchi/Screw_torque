<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Emp_ID = $_GET[Emp];
$Lastchannel_ID = $_GET[LastCH_ID];
$New_Cartname = $_GET[New_Cartname];
$New_Partno = $_GET[New_PartNo];
$New_Channel = $_GET[New_Channel];



 $sql =" 
 UPDATE [STT_DB].[IM].[TBL_ScrewDV_Pm_Channel]
 SET [Channel_Name] = '".$New_Channel."'
    ,[Cart_Name] = '".$New_Cartname."'
    ,[Part_No] = '".$New_Partno."'
    ,[Update_By] = '".$Emp_ID."'
    ,[Create_Date] = GETDATE()
    ,[Update_Date] = GETDATE()
WHERE CH_ID = '".$Lastchannel_ID."'";


$myfunction->exec($sql); 
print_r($sql);

?>