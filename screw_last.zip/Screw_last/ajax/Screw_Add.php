<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Part_No = $_GET[Part_no];
$Screw_Name = $_GET[Screw_name];

$sql="
INSERT INTO [STT_DB].[IM].[SCREW_TQ_ScrewType]
([Screw_Name]
,[Part_No]
,[Create_By]
,[Create_Date]
,[Update_By]
,[Update_Date])
VALUES ('".$Screw_Name."','".$Part_No."','".$Emp_ID."',GETDATE(),'".$Emp_ID."',GETDATE())"; 
 $myfunction->exec($sql);

?>