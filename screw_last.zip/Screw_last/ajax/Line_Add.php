<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Line_Name = $_GET[Line_name];


$sql="
INSERT INTO [STT_DB].[IM].[SCREW_TQ_Line]
           ([Line]
           ,[Create_Date]
           ,[Create_By]
           ,[Update_Date]
           ,[Update_By])
    VALUES('".$Line_Name."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 
    
 $myfunction->exec($sql);

?>