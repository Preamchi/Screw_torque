<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID1 = $_GET[Emp];
$Model1 = $_GET[Model];
$Nijiko1 = $_GET[Nijiko];
$CH1 = $_GET[CH];
$Seq1 = $_GET[Seq];
$SeqB = $_GET[Seq_b];
$Torq1 = $_GET[Tq];
$Torq_Max1 = $_GET[Tq_Max];
$Torq_Min1 = $_GET[Tq_Min];



$sql="
INSERT INTO [STT_DB].[IM].[SCREW_TQ_Sequence]
           ([Sequence]
           ,[Sequence_Before]
           ,[Torque]
           ,[Torque_Max]
           ,[Torque_Min]
           ,[Channel_Id]
           ,[Model_Id]
           ,[Nijiko_Id]
           ,[Create_Date]
           ,[Create_By]
           ,[Update_Date]
           ,[Update_By])
     VALUES ('".$Seq1."','".$SeqB."','".$Torq1."','".$Torq_Max1."','".$Torq_Min1."','".$CH1."','".$Model1."','".$Nijiko1."',GETDATE(),'".$Emp_ID1."',GETDATE(),'".$Emp_ID1."')"; 
 $myfunction->exec($sql);

 print_r($sql);

?>