<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Employee = $_GET[Emp];
$Model_ID = $_GET[Model_ID];
$Model = $_GET[Model];
$Station = $_GET[Station];
$Line = $_GET[Line];



    $sql =" UPDATE [STT_DB].[IM].[SCREW_TQ_Model] SET Model = '".$Model."',Station_Id = '".$Station."',Line_Id = '".$Line."',Update_By = '".$Employee."',Update_Date = GETDATE()
    WHERE ID = '".$Model_ID."'";
    $myfunction->exec($sql); 




?>