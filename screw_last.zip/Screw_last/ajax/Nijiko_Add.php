<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Nijiko_Name = $_GET[Nijiko_Name];
$Station = $_GET[Station];
$Screw = $_GET[Screw];




$sql="
INSERT INTO [STT_DB].[IM].[SCREW_TQ_Nijiko]
           ([Nijiko]
           ,[Station_Id]
           ,[Screw_Id]
           ,[Create_Date]
           ,[Create_By]
           ,[Update_Date]
           ,[Update_By])
VALUES('".$Nijiko_Name."','".$Station."','".$Screw."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 
 $myfunction->exec($sql);

?>