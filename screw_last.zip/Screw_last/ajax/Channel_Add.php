<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Channel_Name = $_GET[ Channel_Name];
$Station_ID = $_GET[Station];
$Model_ID = $_GET[Model];
$PLC = $_GET[PLC];


$sql="
INSERT INTO [STT_DB].[IM].[SCREW_TQ_Channel]
           ([Channel]
           ,[PLC_Ref]
           ,[Model_Id]
           ,[Station_Id]
           ,[Create_Date]
           ,[Create_By]
           ,[Update_Date]
           ,[Update_By])
     VALUES('".$Channel_Name."','".$PLC."','".$Model_ID."','".$Station_ID."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 
 $myfunction->exec($sql);

?>