<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Emp_ID = $_GET[Emp];
$LastN_ID = $_GET[LastN_ID];
$New_Nijiko = $_GET[New_Nijiko];
$New_PartNo  = $_GET[New_PartNo];
$New_Station = $_GET[New_Station];



 $sql =" 
 UPDATE [STT_DB].[IM].[TBL_ScrewDV_Pm_Nijiko]
   SET [Nijiko_Name] = '".$New_Nijiko."'
      ,[ST_ID] = '".$New_Station."'
      ,[Part_No] = '".$New_PartNo."'
      ,[Update_By] = '".$Emp_ID."'
      ,[Update_Date] = GETDATE()
WHERE Machine_ID = '".$LastN_ID."'";

$myfunction->exec($sql); 


?>