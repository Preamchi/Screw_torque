<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Channel_ID= $_GET[Channel_ID];


$sql = " 
SELECT [CH_ID]
,[Channel_Name]
,[Cart_Name]
,[Part_No]
 FROM [STT_DB].[IM].[TBL_ScrewDV_Pm_Channel] WHERE CH_ID = '$Channel_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_channel = $val;
}

$data_channel1 = json_encode($data_channel);
    echo $data_channel1;

    
 
?>