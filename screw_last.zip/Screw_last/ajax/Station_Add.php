<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$ST_Name= $_GET[ST_Name];




$sql="
INSERT INTO [STT_DB].[IM].[SCREW_TQ_Station]
           ([Station]
           ,[Create_Date]
           ,[Create_By]
           ,[Update_Date]
           ,[Update_By])
    VALUES('".$ST_Name."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 

 $myfunction->exec($sql);

?>