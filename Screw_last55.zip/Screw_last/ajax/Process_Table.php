<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();



/* $sql="
SELECT [ID]
,[Sequence]
,[Sequence_Before]
,[Torque]
,[Torque_Max]
,[Torque_Min]
,[Channel_Id]
,[Model_Id]
,[Nijiko_Id]
,[Create_Date] = CONVERT(varchar, [Create_Date],120)
,[Create_By]
,[Update_Date]= CONVERT(varchar, [Update_Date],120)
,[Update_By] 
FROM [STT_DB].[IM].[SCREW_TQ_Sequence]";
 */

 $sql = "
SELECT 
  --A.*,
    --B.*,
    --C.*,
	 --D.*
	A.[ID]
      ,[Sequence]
      ,[Sequence_Before]
      ,[Torque]
      ,[Torque_Max]
      ,[Torque_Min]
	  ,B.[Channel]
	  ,C.[Model]
      ,D.[Nijiko] 
	  ,A.[Create_By]
      ,CONVERT(varchar,A.[Create_Date],120) AS Create_Date
      ,A.[Update_By] 
      ,CONVERT(varchar,A.[Update_Date],120) AS Update_Date
    
  FROM [STT_DB].[IM].[SCREW_TQ_Sequence] A
  LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Channel] B
    ON A.Channel_Id = B.ID
 LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Model] C
	ON A.Model_Id = C.ID
LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Nijiko] D
	ON A.Nijiko_Id = D.ID"; 
 
    
$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

if($getdata <= 0) 
{
    echo '
    <div class="container text-center mt-5">
        Data Not Found!
    </div>
    ';
} else { 
    echo'
    <div class="table-wrapper">
    <table class="table table-bordered" style="margin:0px;">
        <thead class=" text-center thead-dark " style=" font-size: 12px;">
       <tr>
             <th scope="col">No.</th>  
            <th scope="col">Model</th>
            <th scope="col">Nijiko</th>    
            <th scope="col">CH</th>
            <th scope="col">Seq</th>
            <th scope="col">Seq_Before</th>
            <th scope="col">Torque_Max</th> 
            <th scope="col">Torque</th>
            <th scope="col">Torque_Min</th>
            <th scope="col">Create_By</th>
            <th scope="col">Create_Date</th>
           <th scope="col">Update_By</th>
           <th scope="col">Update_Date</th>
           <th scope="col">Tool</th>

    </tr>    
    </thead> ';
 ?>
<?php $a = 1 ?>
<?php foreach($getdata as $x => $val){echo '<tbody class="text-center " style="font-size:14px;">  
    <tr>
        <th scope="row">'.$a++.'</th>
        <td hidden>'.$val[ID].'</td>
        <td class="col-1">'.$val[Model].'</td>
        <td class="col-1">'.$val[Nijiko].'</td>
        <td>'.$val[Channel].'</td>
        <td>'.$val[Sequence].'</td>
        <td>'.$val[Sequence_Before].'</td>
        <td>'.$val[Torque_Max].'</td>
         <td>'.$val[Torque].'</td>
        <td>'.$val[Torque_Min].'</td>
        <td>'.$val[Create_By].'</td>
        <td>'.$val[Create_Date].'</td>
        <td>'.$val[Update_By].'</td>
        <td>'.$val[Update_Date].'</td>
        <td class="col-1">
            <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
                    data-toggle="modal" data-target="#editprocessModal" data-backdrop="static"
                    onclick="Send_ID(\''.$val[ID].'\'),Nijiko_Select1()"><i class="fas fa-pen"></i></button>
                <button type="button" class="btn-delete" onclick="Delete(\''.$val[ID].'\')""><i class=" fas
                    fa-trash-alt"></i></button>
            </div>
        </td>
    </tr>
</tbody>';}

echo '</div></table>';
    }
?>