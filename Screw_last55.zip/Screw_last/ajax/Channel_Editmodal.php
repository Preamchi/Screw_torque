<?php?>
<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Channel_ID= $_GET[Channel_ID];


$sql = " 
SELECT A.[ID]
,[Channel]
,A.[Station_Id] AS ST_ID
,C.[ID] AS Model_ID
,C.[Model] AS Model
,B.[Station] AS StationName
,[PLC_REF]
,A.[Update_By]
,CONVERT(varchar,A.[Create_Date],120) AS Create_Date
,CONVERT(varchar,A.[Update_Date],120) AS Update_Date
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] B 
ON A.Station_Id = B.ID 
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Model] C
ON A.Model_Id = C.ID WHERE A.ID = '$Channel_ID';
";

/* SELECT [CH_ID]
,[Channel_Name]
,[Cart_Name]
,[Part_No]
 FROM [STT_DB].[IM].[TBL_ScrewDV_Pm_Channel] WHERE CH_ID = '$Channel_ID'
 */
 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_channel = $val;
}

$data_channel1 = json_encode($data_channel);
    echo $data_channel1;

    
 
?>