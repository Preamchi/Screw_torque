<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$sql = "
SELECT [Emp_ID]
      ,[Emp_Name]
      ,[Emp_Role]
      ,[Update_By]
      ,[Create_Date] = CONVERT(varchar,[Create_Date],120)
      ,[Update_Date] = CONVERT(varchar,[Update_Date],120)
  FROM [STT_DB].[IM].[SCREW_TQ_User] ORDER BY [Update_Date] ASC ";

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

?>
<div class="table-wrapper">
    <table class="table table-bordered " style="margin:0px;">
        <thead class=" text-center thead-dark " style=" font-size: 12px;">
            <tr>
                <th scope=" col">No.</th>
                <th>Employee ID</th>
                <th scope="col">Username</th>
                <th scope="col">Role</th>
                <th scope="col">Update By</th>
                <th scope="col">Update Date</th>
                <th scope="col">Tool</th>
            </tr>
        </thead>

        <?php $a = 1 ?>
        <?php foreach($getdata as $x => $val)
    {echo '<tbody class="text-center " style="font-size:14px;" >
        <tr>
            <th >'.$a++.'</th>
            <td >'.$val[Emp_ID].'</td>
            <td >'.$val[Emp_Name].'</td>
            <td  >'.$val[Emp_Role].'</td>
            <td >'.$val[Update_By].'</td>
            <td >'.$val[Update_Date].'</td>
            <td class="col-1">
                <div class="d-flex flex-row justify-content-between"> <button type="button" class="btn-edit"
                        data-toggle="modal" data-target="#UserEditModal" onclick="Send_ID(\''.$val[Emp_ID].'\')"   data-backdrop="static">	
                        <i class="fas fa-pen"></i></button>
                    <button type="button" class="btn-delete" onclick="Delete(\''.$val[Emp_ID].'\')""><i class="fas fa-trash-alt"></i></button>
                </div>
            </td>
        </tr>

    </tbody>';} ?>
    </table>
</div>