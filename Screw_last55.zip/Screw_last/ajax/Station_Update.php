<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Emp_ID = $_GET[Emp];
$ST_ID = $_GET[ST_ID];
$New_Station = $_GET[New_Station];



 $sql =" 
 UPDATE [STT_DB].[IM].[SCREW_TQ_Station]
 SET [Station] = '".$New_Station."'
    ,[Update_By] = '".$Emp_ID."'
    ,[Update_Date] = GETDATE()
WHERE ID = '".$ST_ID."'";

$myfunction->exec($sql); 


?>