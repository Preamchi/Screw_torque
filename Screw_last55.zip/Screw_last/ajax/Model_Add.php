<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Model_Name = $_GET[Model_name];
$Station_ID = $_GET[station_id];
$Line_ID = $_GET[line_id];

$sql_check = "
SELECT 
[Model]
,[Station_Id]
,[Line_Id] FROM [STT_DB].[IM].[SCREW_TQ_Model] WHERE Model = '$Model_Name' and Line_Id = '$Line_ID' and Station_Id = '$Station_ID'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;


/* $sql="
INSERT INTO [STT_DB].[IM].[TBL_ScrewDV_Model]
           ([Model_Name]
           ,[Update_By]
           ,[Create_Date]
           ,[Update_Date])
     VALUES('".$Model_Name."','".$Emp_ID."',GETDATE(),GETDATE())";  */

     if($getdata == ''){
      $sql=" 
      INSERT INTO [STT_DB].[IM].[SCREW_TQ_Model]
      ([Model]
      ,[Station_Id]
      ,[Line_Id]
      ,[Create_Date]
      ,[Create_By]
      ,[Update_Date]
      ,[Update_By])
 VALUES ('".$Model_Name."','".$Station_ID."','".$Line_ID."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')";
  $myfunction->exec($sql);
       echo $sql;
           
          }else{
              echo 'have_data';
          }
          
      
   

?>