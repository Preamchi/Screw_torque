<?php

if (!session_id()) { session_start(); }
ob_start(); 

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$name =$_GET[Name];
$password =$_GET[Password];

$_SESSION['Name'] = $name;
$_SESSION["Password"] = $password;


/* echo "User: ".$name."";
echo "Password: ".$password.""; */


$Username = urlencode($name);
$Password = urlencode($password);

$url = "http://43.72.52.159:8002/api/stt_authenticateUser_resframe_apiview/?gid=".$Username."&password=".$Password;

 
  $str_token = 'ce7558f5ed7570384a7cd38be5fcccf083a8a619';

  $context = stream_context_create(array(
    'http' => array(
      'header'  => "Authorization: Token " .$str_token
    )
  ));


  $array = '';
  $data = file_get_contents($url, false, $context);
  $array = json_decode($data, true);
  $array = $array['ResultAuthen'];

 

  if($array[result] == 'PASS'){
    
    $_SESSION['GID'] = $array[gid];
    $_SESSION['NAME'] = $array[emp_name]; 


   $Employee_ID =  $_SESSION['GID']; 

    $sql = " 
    SELECT [Emp_ID] FROM [STT_DB].[IM].[SCREW_TQ_User] WHERE Emp_ID = '$Employee_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;

 
  if( $getdata  == null){
      echo 'no';
    }else{

      foreach($getdata as $x => $val) {
        $data_user = $val;
    }
    
      $get_user = json_encode($data_user);
      echo  'yes';
    }
        
}else{ 
    
     print_r($array[message]);
   
}



?>