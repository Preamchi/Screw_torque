<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


/* $sql = " 
SELECT  [ID],[Channel] FROM [STT_DB].[IM].[SCREW_TQ_Channel] "; */

$ID = $_GET[Model_id]; 


$sql ="
SELECT [ID] 
,[Channel] AS CH
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A WHERE [ID] = '$ID'";


$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata)


?>