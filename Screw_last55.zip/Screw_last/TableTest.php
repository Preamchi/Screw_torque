<?php

include "connect/COMMON.php";
include "ajax/Head.php";
if (!session_id()) { session_start(); }
ob_start(); 

/* User Login */
$admin_login = $_SESSION[Name];

?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">


<!-- <!DOCTYPE html>
<html>

<head>
    <title>List Management</title>
    <style>
    table {
        border-collapse: collapse;
        width: 50%;
    }

    th,
    td {
        border: 1px solid black;
        padding: 8px;
        text-align: left;
    }

    .delete-btn {
        background-color: #f44336;
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        cursor: pointer;
    }
    </style>
</head>

<body>
    <h1>List Management</h1>

    <form id="myForm">
        <input type="text" id="inputItem" placeholder="Enter an item" required>
        <input type="text" id="in" placeholder="Enter an item" required>
        <button type="submit">Add</button>

        <button id="clearBtn">Clear List</button>
    </form>

    <table id="myTable">
        <thead>
            <tr>
                <th>No.</th>
                <th>Item</th>
                <th>Item2</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

    <script>
    // Get the form and table elements
    const form = document.getElementById('myForm');
    const table = document.getElementById('myTable');


    // Function to add a new item to the list
    function addItem(event) {
        event.preventDefault(); // Prevent form submission

        // Get the input value
        const input = document.getElementById('inputItem');
        const input1 = document.getElementById('in');
        const newItem = input.value.trim();
        const newItem = input1.value.trim();
        if (newItem !== '') {
            // Create a new row
            const newRow = document.createElement('tr');

            // Create cells for number, item, and action
            const numberCell = document.createElement('td');
            numberCell.textContent = table.rows.length;

            const itemCell = document.createElement('td');
            itemCell.textContent = newItem;

            const actionCell = document.createElement('td');
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.className = 'delete-btn';

            // Add event listener to delete button
            deleteButton.addEventListener('click', deleteItem);

            // Append cells to the row
            actionCell.appendChild(deleteButton);
            newRow.appendChild(numberCell);
            newRow.appendChild(itemCell);
            newRow.appendChild(actionCell);

            // Append row to the table
            table.querySelector('tbody').appendChild(newRow);

            // Clear the input field
            input.value = '';
        }
    }

    // Function to delete an item from the list
    function deleteItem(event) {
        const row = event.target.parentNode.parentNode; // Get the row
        row.parentNode.removeChild(row); // Remove the row

        // Update the number in each row
        const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
        for (let i = 0; i < rows.length; i++) {
            rows[i].getElementsByTagName('td')[0].textContent = i + 1;
        }
    }

    function clearList() {
        table.querySelector('tbody').innerHTML = '';
    }

    // Add event listener to the form
    form.addEventListener('submit', addItem);

    // Add event listener to the clear button
    clearBtn.addEventListener('click', clearList);
    // Add event listener to the form
    form.addEventListener('submit', addItem);
    </script>
</body>

</html> -->
<!DOCTYPE html>
<html>

<head>
    <title>Table List with Delete Button</title>
    <style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        text-align: left;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    input[type="text"] {
        width: 100%;
        padding: 5px;
        box-sizing: border-box;
    }

    .delete-button {
        background-color: #f44336;
        color: white;
        border: none;
        padding: 6px 12px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 14px;
        cursor: pointer;
    }
    </style>
</head>

<body>
    <input type="text" id="itemInput" placeholder="Enter an item">
    <button onclick="addItem()">Add Item</button>
    <br><br>
    <table id="itemTable">
        <tr>
            <th>Item</th>
            <th>Action</th>
        </tr>
    </table>
    <script>
    function addItem() {
        var item = document.getElementById("itemInput").value;
        if (item === "") {
            alert("Please enter an item.");
            return;
        }

        var table = document.getElementById("itemTable");
        var newRow = table.insertRow(table.rows.length);
        var itemCell = newRow.insertCell(0);
        var actionCell = newRow.insertCell(1);

        itemCell.innerHTML = item;
        actionCell.innerHTML = '<button class="delete-button" onclick="deleteRow(this)">Delete</button>';

        document.getElementById("itemInput").value = "";
    }

    function deleteRow(button) {
        var row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }
    </script>

</body>

</html>