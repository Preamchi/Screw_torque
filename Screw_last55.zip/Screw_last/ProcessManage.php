<?php
include "connect/COMMON.php";
include "ajax/Head.php";

?>

<link href="css/Allpage.css" rel="stylesheet" />




<!------------------------------------ Process Manage ------------------------------------------>

<body>
    <?php require 'component/Tab.php';?>
    <div class="layout">
        <div class="container" id="main">
            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; ">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">
                        <i class="fas fa-cog"></i>
                        <label class="text">Process Manage</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end;  margin-right: 1rem;">
                        <button type="button" class="btn-add" data-toggle="modal" data-target="#AddProcessModal"
                            data-backdrop="static" onclick="Model_Station_Select(),Nijiko_Select(),Channel_Select()"><i
                                class="fas fa-plus-circle"></i>&nbsp;Add Data</button>
                    </div>
                    <!-- screw_data table -->
                    <div id="Show_Process"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Edit -->
    <input id="process_id" hidden />
    <div class="modal fade" id="editprocessModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-pen"></i>&nbsp;Edit Process</h5>
                </div>
                <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                <div class="modal-body pl-5 pr-5">
                    <form>
                        <label>Station Detail</label>
                        <input id="model_st_id" hidden />
                        <input id="channel_id" hidden />
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm">Model-Station</span>
                            </div>
                            <input type="text" class="form-control" aria-label="Small"
                                aria-describedby="inputGroup-sizing-sm" id="model_st_data" disabled>
                        </div>
                        <div class="input-group input-group-sm mb-3 ">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm"
                                    style="width:100px;">Channel</span>
                            </div>
                            <input type="text" class="form-control" aria-label="Small"
                                aria-describedby="inputGroup-sizing-sm" id="channel_data" disabled>
                        </div>
                        <label>Current Nijiko:&nbsp;</label><input type="text" id="nijiko_data"
                            style="border:none; background:none; " disabled /><input id="nijiko_id" hidden />
                        <div class="input-group input-group-sm mb-3 ">
                            <div class="input-group-prepend">
                                <label class="input-group-text " for="inputGroupSelect01"
                                    style="width:100px;">Nijiko</label>
                            </div>
                            <select class="custom-select " id="nijiko2_select" onchange="(this.value)">
                            </select>
                        </div>


                        <label>Sequence Detail</label>
                        <div class="d-flex flex-row ">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroup-sizing-sm"
                                        style="width:100px;">Sequnce</span>
                                </div>
                                <input type="text" class="form-control col-5" aria-label="Small"
                                    aria-describedby="inputGroup-sizing-sm" id="sequnce_data">
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">Sequnce Before</span>
                                </div>
                                <input type="text" class="form-control col-5" aria-label="Small"
                                    aria-describedby="inputGroup-sizing-sm" id="sequnce_before_data">
                            </div>
                        </div>
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm" style="width:100px;">Torque
                                    Max</span>
                            </div>
                            <input type="text" class="form-control " aria-label="Small"
                                aria-describedby="inputGroup-sizing-sm" id="torquemax_data">
                        </div>
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm"
                                    style="width:100px;">Torque</span>
                            </div>
                            <input type="text" class="form-control" aria-label="Small"
                                aria-describedby="inputGroup-sizing-sm" id="torque_data">
                        </div>
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm" style="width:100px;">Torque
                                    Min</span>
                            </div>
                            <input type="text" class="form-control" aria-label="Small"
                                aria-describedby="inputGroup-sizing-sm" id="torquemin_data">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                    <button type=" button" class="btn btn-success" onclick="Update_Process()">Update</button>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Modal Add Ver2 -->
    <input id="id_hold" hidden />
    <div class="modal fade bd-example-modal-xl" id="AddProcessModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-pen"></i>&nbsp;Add Process</h5>
                </div>
                <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                <div class="modal-body pl-4 pr-4">
                    <div class="row">
                        <div class="col-5" style=" border-right: 2px solid #E9ECEF; ">
                            <form id="AddProcess">
                                <label>Station Detail</label>
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text " style="width: 100px;"
                                            for="inputGroupSelect01">Model-Station</label>
                                    </div>
                                    <select class="custom-select " id="model_st_select"
                                        onchange="Channel_Select(this.value)">
                                    </select>
                                </div>
                                <div class="d-flex flex-row ">
                                    <div class="input-group input-group-sm mb-3 col-6 pl-0">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text " for="inputGroupSelect01">Channel</label>
                                        </div>
                                        <select class="custom-select " id="channel_select" onchange="(this.value)">
                                        </select>
                                    </div>
                                    <div class="input-group input-group-sm mb-3 col-6 pr-0">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text " for="inputGroupSelect01">Nijiko</label>
                                        </div>
                                        <select class="custom-select " id="nijiko_select" onchange="(this.value)">
                                        </select>
                                    </div>
                                </div>

                                <label>Sequence Detail</label>
                                <div class="d-flex flex-row ">
                                    <div class="input-group input-group-sm mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroup-sizing-sm"
                                                style="width:100px;">Sequnce</span>
                                        </div>
                                        <input type="text" class="form-control col-5" aria-label="Small"
                                            aria-describedby="inputGroup-sizing-sm" id="seq">
                                    </div>
                                    <div class="input-group input-group-sm mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroup-sizing-sm">Sequnce
                                                Before</span>
                                        </div>
                                        <input type="text" class="form-control col-5" aria-label="Small"
                                            aria-describedby="inputGroup-sizing-sm" id="seq_before">
                                    </div>
                                </div>
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width:100px;">Torque
                                            Max</span>
                                    </div>
                                    <input type="number" class="form-control " aria-label="Small"
                                        aria-describedby="inputGroup-sizing-sm" id="torque_max">
                                </div>
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width:100px;">Torque</span>
                                    </div>
                                    <input type="number" class="form-control" aria-label="Small"
                                        aria-describedby="inputGroup-sizing-sm" id="torque">
                                </div>
                                <div class="input-group input-group-sm mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width:100px;">Torque
                                            Min</span>
                                    </div>
                                    <input type="number" class="form-control" aria-label="Small"
                                        aria-describedby="inputGroup-sizing-sm" id="torque_min">
                                </div>
                                <button type="button" class="btn btn-success  btn-sm" onclick="addItem()">
                                    <i class="fas fa-plus"></i>&nbsp;Add</button>
                                <button type="button" class="btn btn-primary  btn-sm" onclick="clearTable()">Clear Table
                                </button>
                            </form>
                        </div>
                        <div class="col" style="width: 100px; padding-right: 12px;">
                            <label>Data List</label>
                            <table id="dataTable" class="table table-bordered" style="margin:0px; ">
                                <thead class=" text-center white-text" style=" font-size: 12px;">
                                    <tr>
                                        <th>No</th>
                                        <th>Model [Station]</th>
                                        <th>Nijiko No</th>
                                        <th>CH</th>
                                        <th>Seq</th>
                                        <th>Seq_Before</th>
                                        <th>Torque Max</th>
                                        <th>Toque</th>
                                        <th>Torque Min</th>
                                        <th>Delete</th>

                                    </tr>
                                </thead>
                                <tbody class="text-center " style="font-size:14px;">

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                    <button type=" button" class="btn btn-success" onclick="Add_Process()">Save</button>
                </div>
            </div>
        </div>
    </div>
    </div>


    <?php require 'component/Footer.php';?>



    <!--------------------------- Script Function ---------------------------------->
    <!-- Load data func. -->
    <script>
    $(document).ready(function() {
        Load_Process();
    });
    </script>

    <script>
    function Load_Process() {

        document.getElementById("Show_Process").innerHTML = '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/Process_Table.php",
                async: false,
                cache: false,
                success: function(result) {
                    document.getElementById("Show_Process").innerHTML = result;
                }
            });
        }, 1000);
    }
    </script>



    <script>
    function Channel_Select(e) {

        document.getElementById("model_st_select").value = e;
        var model = e;

        $.ajax({
            url: "ajax/Channel_Value.php",
            async: false,
            cache: false,
            data: {
                Model_id: model
            },
            success: function(result) {
                var myJson = JSON.parse(result);

                var cartoptions =
                    "<select class='form-select' aria-label='Default select example' id='channel_select1' >";

                cartoptions += "<option>select....</option>";
                for (let x in myJson) {

                    var id = myJson[x]['ID'];
                    var name = myJson[x]['CH'];
                    cartoptions += "<option value='" + id + "'>" + name + "</option>";
                }
                cartoptions += '</select>';
                document.getElementById("channel_select").innerHTML = cartoptions;

            }
        });
    }
    </script>
    <script>
    function Model_Station_Select() {
        $.ajax({
            url: "ajax/Model_ST_Value.php",
            async: false,
            cache: false,

            success: function(result) {
                var myJson = JSON.parse(result);

                var options =
                    "<select class='form-select' aria-label='Default select example' id='model_st_select1' >";
                options += "<option>select....</option>";

                for (let x in myJson) {

                    var id = myJson[x]['ID'];
                    var model_id = myJson[x]['Model_ID'];
                    var modelname = myJson[x]['Model'];
                    var stname = myJson[x]['Station'];
                    options += "<option value='" +
                        id + "' id='" + model_id + "' >" + modelname + ' [' + stname + '] '
                    "</option>";

                }
                options += '</select>';

                document.getElementById("model_st_select").innerHTML = options;

            }
        });
    }
    </script>

    <script>
    function Nijiko_Select() {
        $.ajax({
            url: "ajax/Nijiko_Value.php",
            async: false,
            cache: false,

            success: function(result) {
                var myJson = JSON.parse(result);

                var options =
                    "<select class='form-select' aria-label='Default select example' id='nijiko_select1' >";
                options += "<option>select....</option>";
                for (let x in myJson) {

                    var id = myJson[x]['ID'];
                    var name = myJson[x]['Nijiko'];
                    options += "<option value='" + id + "'>" + name + "</option>";
                }
                options += '</select>';
                document.getElementById("nijiko_select").innerHTML = options;

            }
        });
    }
    </script>

    <!-- <script>
        // รับแบบฟอร์มเมื่อส่ง
        document.getElementById("AddProcess").addEventListener("submit", function(event) {
        event.preventDefault(); // ปิดการรีเฟรชหน้า

        // ดึงข้อมูลจากฟอร์ม
        var channel = document.getElementById('channel_select').value;
        var nijiko = document.getElementById('nijiko_select').value;
        var seq = document.getElementById('seq').value;
        var seq_before = document.getElementById('seq_before').value;
        var select = document.getElementById("model_st_select");
        /* var selectedOption = select.options[select.selectedIndex];
        var model_id = selectedOption.id; */
        var input1 = parseFloat(document.getElementById("torque_max").value);
        var input2 = parseFloat(document.getElementById("torque").value);
        var input3 = parseFloat(document.getElementById("torque_min").value);

        // เพิ่มข้อมูลลงในตาราง
        addDataToTable(channel, nijiko);

        // เคลียร์ค่าในฟอร์ม
        document.getElementById("seq").value = "";
        document.getElementById("seq_before").value = "";
        });

        // ฟังก์ชันเพิ่มข้อมูลลงในตาราง
        function addDataToTable(channel, nijiko) {
        var table = document.getElementById("dataTable");
        var row = table.insertRow(-1); // เพิ่มแถวใหม่ที่ตำแหน่งสุดท้าย

        // เพิ่มเซลล์ในแถว
        var indexCell = row.insertCell(0);
        var nameCell = row.insertCell(1);
        var ageCell = row.insertCell(2);
        var nameCell = row.insertCell(3);
        var nameCell = row.insertCell(4);
        var nameCell = row.insertCell(5);
        var nameCell = row.insertCell(6);
        var deleteCell = row.insertCell(7);
        var deleteCell = row.insertCell(8);
        var deleteCell = row.insertCell(9);

        // กำหนดข้อมูลให้กับเซลล์
        indexCell.textContent = table.rows.length - 1; // ลำดับที่เท่ากับจำนวนแถวลบหนึ่ง
        nameCell.textContent = name;
        ageCell.textContent = age;
        deleteCell.innerHTML = "<button onclick='deleteRow(this.parentNode.parentNode)'>ลบ</button>";
        console.log(table);
        }

        function deleteRow(row) {

        var table = document.getElementById("dataTable");
        table.deleteRow(row.rowIndex);

        var rows = table.rows;
        for (var i = rowIndex; i < rows.length; i++) { var row=rows[i]; var indexCell=row.cells[0];
            indexCell.textContent=i; } } </script> -->
    <script>
    var allDataArray = [];
    </script>
    <script>
    function addItem() {
        var channel = document.getElementById('channel_select').value;
        var nijiko = document.getElementById('nijiko_select').value;
        var seq = document.getElementById('seq').value;
        var seq_before = document.getElementById('seq_before').value;
        var select = document.getElementById("model_st_select");
        var selectedOption = select.options[select.selectedIndex];
        var model_id = selectedOption.id;
        var input1 = parseFloat(document.getElementById("torque_max").value);
        var input2 = parseFloat(document.getElementById("torque").value);
        var input3 = parseFloat(document.getElementById("torque_min").value);
        var table = document.getElementById("dataTable");

        // ตรวจสอบว่าข้อมูลมีอยู่ในตารางแล้วหรือไม่
        var isDuplicate = checkDuplicateData(table, channel, nijiko, seq, seq_before, model_id);
        if (isDuplicate) {
            alert("ข้อมูลมีอยู่ในตารางแล้ว");
            return;
        }

        var newRow = table.insertRow(table.rows.length);
        var noCell = newRow.insertCell(0);
        var modelCell = newRow.insertCell(1);
        var nijikoCell = newRow.insertCell(2);
        var chCell = newRow.insertCell(3);
        var seqCell = newRow.insertCell(4);
        var seq_beforeCell = newRow.insertCell(5);
        var maxCell = newRow.insertCell(6);
        var torqueCell = newRow.insertCell(7);
        var minCell = newRow.insertCell(8);
        var actionCell = newRow.insertCell(9);


        var rowCount = table.rows.length - 1; // ลบ 1 เพื่อไม่นับแถวหัวตาราง
        noCell.innerHTML = rowCount;
        modelCell.innerHTML = model_id;
        chCell.innerHTML = channel;
        nijikoCell.innerHTML = nijiko;
        seqCell.innerHTML = seq;
        seq_beforeCell.innerHTML = seq_before;
        maxCell.innerHTML = input1;
        torqueCell.innerHTML = input2;
        minCell.innerHTML = input3;
        actionCell.innerHTML = '<i class="fas fa-minus-circle fa-lg delete-icon" onclick="deleteRow(this)"></i>';


        var dataArray = [channel, nijiko, seq, seq_before, model_id, input1, input2, input3];
        allDataArray.push(dataArray);

        clearFormInputs();
    }

    function checkDuplicateData(table, channel, nijiko, seq, seq_before, model_id) {
        var rows = table.rows;
        for (var i = 1; i < rows.length; i++) { // เริ่มต้นที่ดัชนี 1 เพื่อข้ามแถวหัวตาราง
            var row = rows[i];
            var chCell = row.cells[3].innerHTML;
            var nijikoCell = row.cells[2].innerHTML;
            var seqCell = row.cells[4].innerHTML;
            var seq_beforeCell = row.cells[5].innerHTML;
            var modelCell = row.cells[1].innerHTML;

            if (
                chCell === channel &&
                nijikoCell === nijiko &&
                seqCell === seq &&
                seq_beforeCell === seq_before &&
                modelCell === model_id
            ) {
                return true;
            }
        }
        return false;
    }

    function deleteRow(button) {
        var row = button.parentNode.parentNode;
        var table = row.parentNode;
        var rowIndex = row.rowIndex;

        table.deleteRow(rowIndex);

        // อัปเดตหมายเลขแถว
        var rows = table.rows;
        for (var i = rowIndex; i < rows.length; i++) {
            var noCell = rows[i].cells[0];
            noCell.innerHTML = i;
        }

        allDataArray.splice(rowIndex - 1, 1);
    }

    function clearTable() {
        var table = document.getElementById("dataTable");
        var rowCount = table.rows.length;

        // เริ่มต้นจากแถวสุดท้ายและลบแต่ละแถว
        for (var i = rowCount - 1; i > 0; i--) {
            table.deleteRow(i);
        }
        allDataArray = [];
    }

    function clearFormInputs() {
        document.getElementById("channel_select").value = "";
        document.getElementById("nijiko_select").value = "";
        document.getElementById("seq").value = "";
        document.getElementById("seq_before").value = "";
        document.getElementById("torque_max").value = "";
        document.getElementById("torque").value = "";
        document.getElementById("torque_min").value = "";
    }
    </script>
    <script src="js/Update_Process.js"></script>
    <script src="js/Add_Process.js"></script>
    <script src="js/Del_Process.js"></script>
</body>


</html>