
$('#logout').click(function(){

    Swal.fire({
        title: 'Are you sure to log out?',
        width: 350,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'

      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "GET",
                url: "ajax/Logout.php",
                async: false,
                cache: false,

                success: function(result) {

                    Swal.fire({
                        width: 300,
                        title: 'Logout Successfully!',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1600
                      })
                      setTimeout(function() {
                      
                        window.location.href = "index.php";
                        
                       }, 1000); 
                       
                } 
           
            });
        }
      })
 
}); 

