
function Login() {
    
    var user_id = document.getElementById('user_id').value;
    var password = document.getElementById('pw').value;

    if ((!user_id) || (!password)) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          })
    } else {

        $.ajax({
            url: "ajax/Login.php",
            async: false,
            cache: false,
            data: {
                Name: user_id,
                Password: password
            },

            success: function(result) {
           /*alert(result); */

                if (result == 'no'){
                    Swal.fire({
                        width: 400,
                        hight:400,
                        title: 'You don\'t have permission',
                        icon: 'warning',
                        showConfirmButton: false,
                        timer: 1600
                      })

                }else if (result == 'yes'){
                    Swal.fire({
                        width: 350,
                        title: 'Log In Success!',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1600 
                    });
                    setTimeout(function() {
                   
                        window.location.replace("Dashboad.php");
                        
                    }, 1000); 
                    
                 }else {
                    // alert(result);
                    Swal.fire({
                        width: 330,
                        title: result,
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1600
                    })
                 }
              

            }
        })
    }
}


function handleEnterKeyPress(event) {
    // Check if the key is the enter key
    if (event.key === "Enter") {
      event.preventDefault(); // Prevent form submission
      Login(); // Call the login function
    }
  }
  
  // Add event listener to the login-form
  document.getElementById("login-form").addEventListener("keyup", handleEnterKeyPress);
  

