
function Send_ID(e) {

    document.getElementById("screw_id").value = e;
    var scw_id = e;
   
    $.ajax({
        type: "GET",
        url: "ajax/Screw_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Screw_id: scw_id
        },
        success: function(result) {

            const myJson = JSON.parse(result);
            document.getElementById("partno_data").value = myJson.Part_No;
            document.getElementById("screwname_data").value = myJson.Screw_Name;
          
        }
    });

   
}


function Update_Screw() {

    var emp = document.getElementById('emp').value;
    var screw_id = document.getElementById("screw_id").value; 
    var part_no = document.getElementById("partno_data").value;
    var screw_name = document.getElementById("screwname_data").value;

if ((!part_no) || (!screw_name) ) {

    Swal.fire({
        width: 400,
        title: 'Please input informaion!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 1500
      });

} else {

    $.ajax({
        type: "GET",
        url: "ajax/Screw_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          Screw_ID: screw_id,
          Part_No: part_no,
          Screw_Name: screw_name,
        },   
        success: function(result){
            Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              });
          
            $('#EditScrewModal').modal('hide');
            $('.modal-backdrop').remove(); 
            Load_Screw(); 
        }
    });
}
}