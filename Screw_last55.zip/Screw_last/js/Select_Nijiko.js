function Nijiko_Value() {
    $.ajax({
        url: "ajax/Nijiko_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
         
            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
            cartoptions += "<option>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Nijiko'];
                cartoptions += "<option value='" + id + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("nijiko_loop").innerHTML = cartoptions;
            
        }
    });
}