<?php

include "connect/COMMON.php";
include "ajax/Head.php";

?>

<link href="css/StationManage.css" rel="stylesheet" />

<body>
    <?php require 'component/Tab.php';?>
    <div class="layout">
        <div class="container" id="main">
            <!----------------------------------- Line ------------------------------------------------------>
            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem; margin-top: 73rem;">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">
                        <i class="fas fa-wave-square"></i>
                        <label class="text">Line</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end;  margin-right: 1rem;">
                        <button type="button" class="btn-add" data-toggle="modal" data-target="#AddLineModal"
                            data-backdrop="static"><i class="fas fa-plus-circle"></i>&nbsp; Add Data
                        </button>
                    </div>
                    <!-- screw_data table -->
                    <div id="show_line" class="scroll"></div>
                </div>
            </div>

            <!-- Line Add -->
            <div class=" modal fade" id="AddLineModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered " role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                <i class="fas fa-plus-circle"></i>&nbsp;Add Line
                            </h5>
                        </div>
                        <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                        <div class="modal-body p-5">
                            <form class="col" id="addline">
                                <div class="input-group input-group-sm ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm">Line Name</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="linename_input">
                                </div>

                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                onclick="Clear_Line()">Cancel</button>
                            <button type="submit" class="btn btn-success" onclick="Add_Line()">Save</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Line Edit -->
            <input id="line_id" hidden />
            <div class=" modal fade" id="EditLineModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered " role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                <i class="fas fa-plus-circle"></i>&nbsp;Edit Line
                            </h5>
                        </div>
                        <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                        <div class="modal-body p-5">
                            <form>

                                <div class="input-group input-group-sm ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm">Line Name</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="linename_data">
                                </div>

                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success" onclick="Update_Line()">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <!----------------------------------- Station ------------------------------------------------------>

            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem;  margin-top: 2rem;">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">

                        <i class="fas fa-pallet"></i>
                        <label class="text">Station</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end;  margin-right: 1rem;">
                        <button type="button" class="btn-add" data-toggle="modal" data-target="#AddStationModal"
                            data-backdrop="static"><i class="fas fa-plus-circle"></i>&nbsp; Add
                            Data
                        </button>
                    </div>
                    <!-- screw_data table -->
                    <div id="show_station" class="scroll"></div>

                </div>
            </div>
            <!-- Station Add -->
            <div class=" modal fade" id="AddStationModal" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                <i class="fas fa-plus-circle"></i>&nbsp;Add Station
                            </h5>
                        </div>
                        <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                        <div class="modal-body p-5">
                            <form class="col" id="addstation">
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm">Station Name</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="stname_input">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                onclick="Clear_ST()">Cancel</button>
                            <button type="submit" class="btn btn-success" onclick="Add_Station()">Save</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Station Edit -->
            <input id="station_id" hidden />
            <div class=" modal fade" id="EditStationModal" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                <i class="fas fa-plus-circle"></i>&nbsp;Edite Station
                            </h5>
                        </div>
                        <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                        <div class="modal-body p-5">
                            <form>
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm">Station Name</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="station_data">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success" onclick="Update_Station()">Save</button>
                        </div>
                    </div>
                </div>
            </div>

            <!----------------------------------------- Model ------------------------------------------------>
            <div class="card "
                style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:5rem; margin-top: 2rem;">
                <div class="card-body pt-0 pl-0">

                    <div class="topic">

                        <i class="fas fa-archive"></i>
                        <label class="text">Model</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end;  margin-right: 1rem;">
                        <button type="button" class="btn-add" data-toggle="modal" data-target="#AddmodelModal"
                            data-backdrop="static" onclick="Line_Value(),Station_Value()"><i
                                class="fas fa-plus-circle"></i>&nbsp; Add
                            Data
                        </button>
                    </div>
                    <!-- screw_data table -->
                    <div id="show_model" class="scroll"></div>

                </div>
            </div>

        </div>
        <!-- Model Add -->
        <div class=" modal fade" id="AddmodelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">
                            <i class="fas fa-plus-circle"></i>&nbsp;Add Model
                        </h5>
                    </div>
                    <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                    <div class="modal-body p-5">
                        <form class="col" id="Addmodel">

                            <div class="input-group input-group-sm  mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">Model Name</span>
                                </div>
                                <input type="text" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-sm" id="modelname_input">
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 100px;"
                                        for="inputGroupSelect01">Line</label>
                                </div>
                                <select class="custom-select " id="line_loop" onchange="(this.value)">

                                </select>
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 100px;"
                                        for="inputGroupSelect01">Station</label>
                                </div>
                                <select class="custom-select " id="station_loop2" onchange="(this.value)">

                                </select>
                            </div>

                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                            onclick="Clear_Model()">Cancel</button>
                        <button type="submit" class="btn btn-success" onclick="Add_Model()">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit model  -->
        <input id="id_model" hidden />
        <div class=" modal fade" id="EditmodelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">
                            <i class="fas fa-plus-circle"></i>&nbsp;Edit Model
                        </h5>
                    </div>
                    <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                    <div class="modal-body p-5">
                        <form>
                            <!--   <div class="input-group input-group-sm  mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroup-sizing-sm">Model Name</span>
                                </div>
                                <input type="text" class="form-control" aria-label="Sizing example input"
                                    aria-describedby="inputGroup-sizing-sm" id="modelname_data" disabled>
                            </div> -->
                            <label>Model:&nbsp;</label><input type="text" id="modelname_data"
                                style="border:none; background:none; " disabled />
                            <input type="text" id="line_data1" hidden /><input type="text" id="lineID" hidden />
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 100px;" for="inputGroupSelect01">
                                        Line</label>
                                </div>
                                <select class="custom-select " id="line_loop1" onchange="(this.value)">

                                </select>
                            </div>

                            <input type="text" id="station_data2" hidden /><input type="text" id="stationID" hidden />
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 100px;" for="inputGroupSelect01">
                                        Station</label>
                                </div>
                                <select class="custom-select " id="station_loop1" onchange="(this.value)"></select>

                            </div>

                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success" onclick="Update_Model()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php require 'component/Footer.php';?>

    <!--------------------------- script function and JS file ---------------------------------->
    <!-- Load Line Data Func. -->
    <script>
    $(document).ready(function() {
        Load_Line();
    });
    </script>

    <script>
    function Load_Line() {
        document.getElementById("show_line").innerHTML =
            '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/Line_Table.php",
                async: false,
                cache: false,

                success: function(result) {
                    document.getElementById("show_line").innerHTML = result;
                }
            });
        }, 1000);
    }
    </script>

    <script>
    function Clear_Line() {
        $("#addline").trigger("reset");
    }
    </script>

    <script src='js/function/Add_Line.js'></script>
    <script src='js/function/Update_Line.js'></script>
    <script src='js/function/Del_Line.js'></script>

    <!-- Load Station Data Func. -->
    <script>
    $(document).ready(function() {
        Load_Station();
    });
    </script>
    <script>
    function Load_Station() {
        document.getElementById("show_station").innerHTML =
            '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/Station_Table.php",
                async: false,
                cache: false,

                success: function(result) {
                    document.getElementById("show_station").innerHTML =
                        result;
                }
            });
        }, 1000);
    }
    </script>
    <script>
    function Clear_ST() {
        $("#addstation").trigger("reset");
    }
    </script>

    <script src='js/function/Add_Station.js'></script>
    <script src='js/function/Del_Station.js'></script>
    <script src='js/function/Update_Station.js'></script>


    <!-- Load Model Data Func. -->
    <script>
    $(document).ready(function() {
        Load_Model();
    });
    </script>
    <script>
    function Load_Model() {
        document.getElementById("show_model").innerHTML =
            '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/Model_Table.php",
                async: false,
                cache: false,

                success: function(result) {
                    document.getElementById("show_model").innerHTML =
                        result;
                }
            });
        }, 1000);
    }
    </script>
    <script>
    function Clear_Model() {
        $("#Addmodel").trigger("reset");
        document.getElementById("modelname_input").value = '';
        document.getElementById("line_loop").value = '0';
        document.getElementById("station_loop2").value = '0';
    }
    </script>
    <script src='js/function/Update_Model.js'></script>
    <script src='js/function/Add_Model.js'></script>
    <script src='js/function/Del_Model.js'></script>
    <script src='js/Select_Model.js'></script>
    <script src='js/Select_Line.js'></script>
    <script src='js/Select_Station.js'></script>
    <script src='js/Select_Station2.js'></script>






</body>

</html>