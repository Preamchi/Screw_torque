<style>
* {
    padding: 0;
    margin: 0
}

#nav a.active {
    color: #fff;
}
</style>



<body>
    <input id="employee_login" value="<?php echo $emp; ?>" hidden />
    <div id="mySidebar" class="sidebar" onmouseover="toggleSidebar()" onmouseout="toggleSidebar()">
        <img class="logo" src="img/screw3.svg" alt="logo" /><label class="text-logo ">Screw.Torque</label>
        <div class="line"></div>
        <div id="nav">
            <a href="Profile.php"><i class="fas fa-address-card"></i><span class="icon-text">My
                    Profile</span></a>
            <a href="Dashboad.php"><i class="fas fa-table"></i><span class="icon-text">Dashboard</span></a>
            <a href="UserManage.php"><i class="fas fa-user-friends"></i><span class="icon-text">User
                    Manage</span></a>
            <a href="ScrewManage.php"><i class="fas fa-cog"></i><span class="icon-text">Screw
                    Manage</span></a>
            <a href="StationManage.php"><i class="fas fa-exchange-alt"></i><span class="icon-text">Station
                    Manage</span></a>
            <a href="NijikoManage.php"><i class="fas fa-screwdriver"></i><span class="icon-text">Nijiko
                    Manage</span></a>
            <a href="ChannelManage.php" style="
    padding-left: 18px;"><i class=" fas fa-grip-horizontal"></i><span class="icon-text" style="
    padding-left: 1px;">Channel
                    Manage</span></a>

            <a href="ProcessManage.php"><i class="fas fa-stream"></i><span class="icon-text">Sequence Manage</span></a>
            <a href=""> <i class="fas fa-book-reader"></i><span class="icon-text">User
                    Manual</span></a>
            <button onclick="logout" id="logout" style="
    padding-top: 0px;"><i class=" fas fa-sign-out-alt"></i><span class="icon-text">Log
                    out</span></button>

        </div>
    </div>
    <!--     <input id="role" idden /> -->
</body>

<script>
var mini = true;

function toggleSidebar() {
    if (mini) {

        document.getElementById("mySidebar").style.width = "230px";
        document.getElementById("main").style.marginLeft = "0px";
        this.mini = false;
    } else {

        document.getElementById("mySidebar").style.width = "65px";
        document.getElementById("main").style.marginLeft = "65px";
        this.mini = true;
    }
}
</script>

<script type="text/javascript">
$(function() {

    $('#nav a').each(function() {
        var path = window.location.href;
        var current = path.substring(path.lastIndexOf('/') + 1);
        var url = $(this).attr('href');


        /* 
                if (userRole === 'User' && url === 'UserManage.php') {
                    $(this).hide(); // Hide the menu item
                }
         */
        if (url == current) {
            $(this).addClass('active');
        };
    });
});
</script>

<!-- <script>
function Check_Role() {
    var emp_login = document.getElementById("employee_login").value;

    $.ajax({
        url: "ajax/User_Profile.php",
        async: false,
        cache: false,
        data: {
            Emp_Login: emp_login
        },
        success: function(result) {

            const myJson = JSON.parse(result);
            document.getElementById("emp_id").value = myJson.Emp_ID;
            document.getElementById("emp_name").value = myJson.Emp_Name;
            document.getElementById("emp_role").value = myJson.Emp_Role;
        }
    });

}
</script> -->
<script type="text/javascript" src="js/function/Logout.js"></script>