<?php

include "connect/COMMON.php";
include "ajax/Head.php";
/* if (!session_id()) { session_start(); }
ob_start();  */

?>

<link href="css/Allpage.css" rel="stylesheet" />





<body>
    <?php require 'component/Tab.php';?>
    <div class="layout">
        <div class="container" id="main">
            <!----------------------------------- Cart-Nigiko Log ----------------------------------------------------->
            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; ">
                <div class="card-body pt-0 pl-0">

                    <div class="topic">
                        <label class="text">Result Torque</label>
                    </div>
                    <div id="show_result" class="scroll"></div>

                </div>
            </div>
            <?php require 'component/Footer.php';?>




            <!----------------------------------- Station-Nijikio Log ------------------------------------------------------>

            <!-- Load data func. -->
            <script>
            $(document).ready(function() {
                Load_Result();
            });
            </script>

            <script>
            function Load_Result() {
                document.getElementById("show_result").innerHTML =
                    '<div class="center"><span class="loader"></span></div>';

                setTimeout(function() {
                    $.ajax({
                        url: "ajax/Torque_Table.php",
                        async: false,
                        cache: false,

                        success: function(result) {
                            document.getElementById("show_result").innerHTML = result;
                        }
                    });
                }, 1000);
            }
            </script>
</body>

</html>