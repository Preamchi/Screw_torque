<?php

include "connect/COMMON.php";
include "ajax/Head.php";


?>


<link href="css/Allpage.css" rel="stylesheet" />

<body>
    <!-- Menu Tab Left-->
    <?php require 'component/Tab.php';?>

    <div class="layout">
        <!-- Card UserManage -->
        <div class="container" id="main">
            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; ">
                <div class="card-body pt-0 pl-0">
                    <!-- Head Topic -->
                    <div class="topic">
                        <i class="fas fa-user-friends"></i>
                        <label class="text">User Manage</label>
                    </div>

                    <div style=" display:flex;  margin-top:5rem; flex-direction: row; justify-content: space-between;">
                        <div class="input-group input-group-sm mb-3 col-3 ml-3">
                            <!--    <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm">Search</span>
                            </div> -->
                            <!--    <input type="text" class="form-control" aria-label="Small"
                                aria-describedby="inputGroup-sizing-sm"> -->
                        </div>

                        <!-- Button Add User -->
                        <div style=" margin-right:1rem;">
                            <button type="button" class="btn-add" data-toggle="modal" data-target="#AddUserModal"
                                data-backdrop="static"><i class="fas fa-user-plus"></i>&nbsp; Add User</button>
                        </div>
                    </div>
                    <!-- user_data table -->
                    <div id="show_user"></div>
                </div>
            </div>


            <!--------------------------- All Modal ---------------------------------->
            <!-- Modal Add -->
            <div class="modal fade" id="AddUserModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-user-plus"></i>&nbsp;Add
                                User</h5>
                        </div>
                        <input id="admin_login" value="<?php echo $emp; ?>" hidden />
                        <div class="modal-body p-5">
                            <form id="adduser">
                                <input id="emp_gid" hidden />
                                <label for="exampleFormControlInput1">Employee ID</label>
                                <div class="form-group d-flex justify-content-between">
                                    <input type="text" class="form-control col-lg-10" id="input"
                                        placeholder="GID (10 digit) OR ID (8 digit)">
                                    <button type="button" class="btn btn-primary" onclick="Search_User()"><i
                                            class="fas fa-search"></i></button>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Employee Name</label>
                                    <input type="text" class="form-control" id="emp_name" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Role</label>
                                    <select class="form-select" aria-label="Default select example" id="emp_role">
                                        <option value="0" disabled selected>Select Role...</option>
                                        <option value="Admin">Admin</option>
                                        <option value="User">User</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                onclick="Clear_Form()">Cancel</button>
                            <button type="button" class="btn btn-success" onclick="Add_User()">Save</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal Edit -->
            <input id="user_id" hidden />
            <div class="modal fade" id="UserEditModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-user-edit"></i>&nbsp;Edit
                                User
                            </h5>
                        </div>

                        <div class="modal-body p-5">
                            <!-- Employee_Id OF User Log In -->
                            <input id="admin_login" value="<?php echo $emp; ?>" hidden />
                            <!-- Form User Edit -->
                            <form id="edituser">
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Employee ID: </label>
                                    <input id="employee_id" style="border:none; outline: none;" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Emplyee Name: </label>
                                    <input id="employee_name" style="border:none; outline: none;" readonly />
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Current Role: <input id="employee_role"
                                            style="border:none; outline: none;" readonly /></label>
                                    <select class="form-select" aria-label="Default select example" id="role_value"
                                        onchange="(this.value)">
                                        <option value="0" selected disabled>Role new...</option>
                                        <option value="Admin">Admin</option>
                                        <option value="User">User</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                onclick="Clear_Form()">Cancel</button>
                            <button type="button" class="btn btn-success" onclick="Update_User()"
                                id="myBtn">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php require 'component/Footer.php';?>
    <!--------------------------- script function and JS file ---------------------------------->

    <!-- Load data func. -->
    <script>
    $(document).ready(function() {
        Load_User();
    });
    </script>

    <script>
    function Load_User() {
        document.getElementById("show_user").innerHTML = '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/User_Table.php",
                async: false,
                cache: false,

                success: function(result) {
                    document.getElementById("show_user").innerHTML = result;
                }
            });
        }, 1000);
    }
    </script>

    <script>
    function Clear_Form() {
        $("#adduser").trigger("reset");
        document.getElementById("role_value").value = '0';
    }
    </script>

    <script src="js/function/Search_User.js"></script>
    <script src="js/function/Add_User.js"></script>
    <script src="js/function/Update_User.js"></script>
    <script src="js/function/Del_User.js"></script>

</body>

</html>