
function Send_ID(e) {
    
    document.getElementById("channel_id").value = e;
    var channel_id = e;

    $.ajax({
        type: "GET",
        url: "ajax/Channel_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Channel_ID: channel_id
        },

        success: function(result) {
       
        const myJson = JSON.parse(result);
      
             document.getElementById("chname_data").value = myJson.Channel;
            document.getElementById("plc_data").value = myJson.PLC_REF;
            document.getElementById("model_data").value = myJson.Model; 
            document.getElementById("station_data").value = myJson.Station; 
            document.getElementById("line_data").value = myJson.Line; 
        /*     document.getElementById("model_id").value = myJson.Model_ID; 
            document.getElementById("station_id").value = myJson.ST_ID;  */
        
        }
    });
}
 

/* function Model_value1() {
    var model = document.getElementById("model_id").value; 
    $.ajax({
        url: "ajax/Model_value.php",
        async: false,
        cache: false,

        success: function(result) {

          var myJson = JSON.parse(result);
         
            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='model_new1' >";
            cartoptions += "<option value='"+model+"'>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Model'];
                cartoptions += "<option value='" + name + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("model_loop1").innerHTML = cartoptions;
            var select = document.getElementById("model_loop1");
            var selectedOption = select.options[select.selectedIndex];
            var selectedId = selectedOption.id;
             
        }
    });
}

function Station_value1(e) {
    
    document.getElementById("model_loop1").value = e;
    var model = e;
    var station = document.getElementById("station_id").value; 

    $.ajax({
        url: "ajax/Station_Select.php",
        async: false,
        cache: false,
        data: {
         Model : model
          }, 
        success: function(result) {
    
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
           options += "<option value='"+station+"'>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ST_ID'];
                var model_id = myJson[x]['Model_ID'];
                var name = myJson[x]['Station'];
               options += "<option value='" + id +"' id='"+model_id+"'>" + name +"</option>";
            }
            options += '</select>';
            document.getElementById("station_loop1").innerHTML = options;
    

        }   
    });
} */
 

 function Update_Channel() {
    var emp = document.getElementById('emp').value;
    var last_id = document.getElementById("channel_id").value; 
    var channel = document.getElementById("chname_data").value;
    var plc = document.getElementById("plc_data").value;
  /*   var station = document.getElementById("station_id").value; 
    var model = document.getElementById("model_id").value;  

    var select = document.getElementById("station_loop1");
    var selectedOption = select.options[select.selectedIndex];
    var selectedId = selectedOption.id;   */

/*  console.log(emp, station,last_id, channel,plc,selectedId);  */


if ((!channel) || (!plc) ) {
    Swal.fire({
        width: 400,
        title: 'Please input informaion!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 1500
      });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Channel_Update.php",
            async: false,
            cache: false,
            data: {
            Emp: emp,
            LastCH_ID: last_id,
            CH : channel ,
            PLC : plc,
         /*    Station : station,
            New_Model : model */
        
            },
            
            success: function(result) {
                if(result == 'have_data'){
                    Swal.fire({
                        width: 400,
                        title: 'Add failed!',
                        text: 'User information already exists.',
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1500
                    });
                }else{
                Swal.fire({
                    width: 400,
                    title: 'Update Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                });
        
                $('#EditChannelModal').modal('hide');
                $('.modal-backdrop').remove(); 
                Load_Channel(); 
                }
            }
        });
 
    }
}   