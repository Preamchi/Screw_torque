
function Send_ID(e) {

    document.getElementById("nijiko_id").value = e;
    var nijiko_id = e;


    $.ajax({
        type: "GET",
        url: "ajax/Nijiko_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Nijiko_ID : nijiko_id
        },

        success: function(result) {
            const myJson = JSON.parse(result);
            document.getElementById("nijiko_data").value = myJson.Nijiko;
            document.getElementById("screw_data").value = myJson.Screw; 
            document.getElementById("station_data").value = myJson.Station;
           document.getElementById("screw_id").value = myJson.Screw_Id; 
            document.getElementById("station_id").value = myJson.Station_Id; 
        
        
          
           
        }
    });

   
}
 
function Station_Value1() {
    var station_id = document.getElementById("station_id").value; 
    var station_name = document.getElementById("station_data").value; 

    $.ajax({
        url: "ajax/Station_Value.php",
        async: false,
        cache: false,
     
        success: function(result) {
        /*     console.log(result); */
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
           options += "<option value='"+station_id +"' >"+station_name+"</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Station'];

                if (!station_id.includes(id)) {
                    options += "<option value='" + id + "'>" + name + "</option>";
                }
           
            }
            options += '</select>';
         
       
            document.getElementById("station").innerHTML = options;
  

        }   
    });
}


function Screw_Value1() {
    var screw_id = document.getElementById("screw_id").value; 
    var screw_name = document.getElementById("screw_data").value; 
    $.ajax({
        url: "ajax/Screw_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
           options += "<option value='"+screw_id+"'>"+screw_name+"</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Screw_Name'];
             
                if (!screw_id.includes(id)) {
                    options += "<option value='" + id + "'>" + name + "</option>";
                }
            }
            options += '</select>';

            document.getElementById("screw").innerHTML = options;
            
        }
    });
}

function Update_Nijiko() {
    var emp = document.getElementById('emp').value;
    var nijiko_id = document.getElementById("nijiko_id").value; 
    var new_nijiko = document.getElementById("nijiko_data").value;
    var new_station = document.getElementById("station").value;
    var new_screw = document.getElementById("screw").value; 

/* console.log(emp, new_partno, new_cartname,channel_id,new_channel); */


    if ((!new_nijiko)) {
        Swal.fire({
            width: 400,
            title: 'Input Nijiko Name Please!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 2000,
        })
    } else {
            $.ajax({
                type: "GET",
                url: "ajax/Nijiko_Update.php",
                async: false,
                cache: false,
                data: {
                    Emp: emp,
                    Niji_ID: nijiko_id,
                    Screw : new_screw,
                    Station : new_station,
                    Nijiko : new_nijiko
            
                },
                
                success: function(result) {
                    if(result == 'have_data'){ 
                        
                        Swal.fire({
                            width: 400,
                            title: 'Add failed!',
                            text: 'information already exists.',
                            icon: 'error',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        document.getElementById("nijiko_input").value = '';
                        document.getElementById("station_loop2").value = '';
                        document.getElementById("screw_loop").value = '';
                
                    }else{
                        Swal.fire({
                            width: 400,
                            title: 'Update Successfully!',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 1500
                        }); 
                        $('#EditNijikoModal').modal('hide');
                        $('.modal-backdrop').remove();
                        Load_Nijiko(); 
                    }
                }
            });
    }
}  