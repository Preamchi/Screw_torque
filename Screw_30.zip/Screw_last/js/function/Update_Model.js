
function Send_model(e) {

    document.getElementById("id_model").value = e;
    var model_id = e;


    $.ajax({
        type: "GET",
        url: "ajax/Model_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Model_ID : model_id
        },

        success: function(result) {
        console.log(result); 
            const myJson = JSON.parse(result);

            document.getElementById("modelname_data").value = myJson.Model;
            document.getElementById("station_data2").value = myJson.Station; 
            document.getElementById("line_data1").value = myJson.LineName; 
            document.getElementById("lineID").value = myJson.LineID; 
            document.getElementById("stationID").value = myJson.StationID; 
           
        }
    });

   
}

function Line_value1() {
    var line = document.getElementById("lineID").value;
    var line_last = document.getElementById("line_data1").value; 
    $.ajax({
        url: "ajax/Line_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
               options += "<option value='"+line+"' >"+line_last+"</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Line'];
            /*     options += "<option value='" + id + "'>" +
                    name + "</option>"; */

                    if (!line.includes(id)) {
                        options += "<option value='" + id + "'>" + name + "</option>";
                    }
                   
            }
           options += '</select>';

            document.getElementById("line_loop1").innerHTML = options;
            
        }
    });
}

function Station_value1() {
    var st_id = document.getElementById("stationID").value; 
    var st_last = document.getElementById("station_data2").value; 
   
    $.ajax({
        url: "ajax/Station_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
          options += "<option value="+st_id+" >"+st_last+"</option>";  
  
            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Station'];

                /*  if (id !== st_id) {
                    options += "<option value='" + id + "'>" + name + "</option>";
                }  */
              if (!st_id.includes(id)) {
                    options += "<option value='" + id + "'>" + name + "</option>";
                }
               
            } 
            options += '</select>';

            document.getElementById("station_loop1").innerHTML = options;
            
        }
    });
}
 


function Update_Model() {
    var emp = document.getElementById('emp').value;
    var model_id = document.getElementById("id_model").value; 
    var new_model = document.getElementById("modelname_data").value;
    var new_line = document.getElementById("line_loop1").value;
    var new_station = document.getElementById("station_loop1").value; 
    var LineID= document.getElementById("line_id").value; 
    var ST_id = document.getElementById("station_id").value; 

/* console.log(model_id,new_model, new_line, new_station,line1); */

if ((!new_model)) {
    Swal.fire({
        width: 400,
        title: 'Input Mdel Name Please!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 2000,
      })
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Model_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          Model_ID: model_id,
          Model: new_model,
          Station : new_station,
          Line : new_line,
          ST_ID : ST_id,
          Line_ID : LineID
       
        },
        success: function(result){
            if(result == 'have_data'){ 
                 
                Swal.fire({
                width: 400,
                title: 'Add failed!',
                text: 'information already exists.',
                icon: 'error',
                showConfirmButton: false,
                timer: 1500
              });
              document.getElementById("modelname_input").value = '';
          
            }else{
             Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              }); 
        
            $('#EditmodelModal').modal('hide');
            $('.modal-backdrop').remove();
            Load_Model(); 
        }
    }
    });

}
}  