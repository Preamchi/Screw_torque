function Add_User() {
    var admin = document.getElementById('admin_login').value;
    var emp = document.getElementById('emp_gid').value;
    var emp_name = document.getElementById('emp_name').value;
    var emp_role = document.getElementById('emp_role').value;   

    if ((!emp) || (!emp_name) || (!emp_role) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/User_Add.php",
            async: false,
            cache: false,
            data: {
                Admin: admin,
                Emp: emp,
                Emp_name: emp_name,
                Emp_role: emp_role
            
            },
            success: function(result) {
                    if (result == 'have_user') {
            Swal.fire({
                width: 400,
                title: 'Add failed!',
                text: 'User information already exists.',
                icon: 'error',
                showConfirmButton: false,
                timer: 1700
              });
              document.getElementById("emp_name").value = '';
              document.getElementById('emp_role').selectedIndex = 0; 
          } else {
             Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1700
                  });

           $('#AddUserModal').modal('hide');
           $('.modal-backdrop').remove();
           $("#adduser").trigger("reset");
           Load_User();
     }
          }
               
        });
    
    }
}
