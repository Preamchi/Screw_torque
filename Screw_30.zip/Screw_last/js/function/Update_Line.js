
function SendLine_ID(e) {

    document.getElementById("line_id").value = e;
    var line_id = e;

    $.ajax({
        type: "GET",
        url: "ajax/Line_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Line_Id: line_id
        },

        success: function(result) {

        const myJson = JSON.parse(result);
        document.getElementById("linename_data").value = myJson.Line; 
           
        }
    });

   
}

function Update_Line() {
    var emp = document.getElementById('emp').value;
    var line_id = document.getElementById("line_id").value; 
    var new_linename = document.getElementById("linename_data").value;
/*   console.log(line_id ,new_linename); */

if ((!new_linename)) {
    Swal.fire({
        width: 400,
        title: 'Please input informaion!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 1500
      });
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Line_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          Line_ID: line_id,
          New_line: new_linename,
     
        },   
        success: function(result){
            if(result == 'have_data'){ 
                Swal.fire({
                width: 400,
                title: 'Add failed!',
                text: 'User information already exists.',
                icon: 'error',
                showConfirmButton: false,
                timer: 1700
              });
              document.getElementById("linename_input").value = '';
            }else{
            Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              });
       
            $('#EditLineModal').modal('hide');
            $('.modal-backdrop').remove(); 
            Load_Line(); 
        }
    }
    });
}
} 