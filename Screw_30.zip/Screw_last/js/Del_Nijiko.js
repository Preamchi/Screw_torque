function Delete(e) {

    var machine_id = e;

 Swal.fire({
        title: 'Do you want to delete?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
        width: 400
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "GET",
                url: "ajax/Nijiko_Del.php",
                async: false,
                cache: false,
                data: {
                    Machine_ID: machine_id
                },
                success: function(result) {
                    Swal.fire({
                        width: 400,
                        title: 'Delete Successfully!',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1500
                    });
                    Load_Nijiko();
                }
            });
        }
})
}

