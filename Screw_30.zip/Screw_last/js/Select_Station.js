function Station_where(e) {
    document.getElementById("model_loop").value = e;
    var model = e;
/*     console.log(model);
 */
    $.ajax({
        url: "ajax/Station_Select.php",
        async: false,
        cache: false,
        data: {
         Model : model
          }, 
        success: function(result) {
      
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
                options += "<option value='0' disabled selected>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ST_ID'];
                /* var model_id = myJson[x]['Model_ID']; */
                var name = myJson[x]['Station'];
               options += "<option value='" + id +"'>" + name +"</option>";
            }
            options += '</select>';
         
            document.getElementById("station_loop").innerHTML = options;

        }   
    });
}