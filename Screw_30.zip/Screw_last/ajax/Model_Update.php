<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Employee = $_GET[Emp];
$Model_ID = $_GET[Model_ID];
$Model = $_GET[Model];
$Station = $_GET[Station];
$Line1 = $_GET[Line];

/*  echo($Station.''. $Line1);  */

$sql_check = "
SELECT 
[Model]
,[Station_Id]
,[Line_Id] FROM [STT_DB].[IM].[SCREW_TQ_Model] WHERE Model = '$Model' and Line_Id = '$Line1' and Station_Id = '$Station'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){
   
   $sql =" UPDATE [STT_DB].[IM].[SCREW_TQ_Model] SET Model = '".$Model."',Station_Id = '".$Station."',Line_Id = '".$Line1."',Update_By = '".$Employee."',Update_Date = GETDATE()
   WHERE ID = '".$Model_ID."'";
   $myfunction->exec($sql); 
echo($sql);
       }else{
           echo 'have_data';
       }
       
   

 /*    $sql =" UPDATE [STT_DB].[IM].[SCREW_TQ_Model] SET Model = '".$Model."',Station_Id = '".$Station."',Line_Id = '".$Line1."',Update_By = '".$Employee."',Update_Date = GETDATE()
    WHERE ID = '".$Model_ID."'";
    $myfunction->exec($sql); 
 echo($sql); */



?>