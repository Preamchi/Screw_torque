<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = "
SELECT [ID]
      ,[Line]
      ,[Create_Date] = CONVERT(varchar, [Create_Date],120)
      ,[Create_By]
      ,[Update_Date] = CONVERT(varchar, [Update_Date],120)
      ,[Update_By]
  FROM [STT_DB].[IM].[SCREW_TQ_Line] ORDER BY [Update_Date] ASC;";

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;


/* ?>


<table class="table" style="width: -webkit-fill-available;">
    <thead class="text-center">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Line Name</th>
            <th scope="col">Create By</th>
            <th scope="col">Create Date</th>
            <th scope="col">Update By</th>
            <th scope="col">Update Date</th>
            <th scope="col">Tool</th>
        </tr>
    </thead>

    <?php $a = 1 ?>
    <?php foreach($getdata as $x => $val){echo '<tbody class="text-center ">
        <tr>
            <th scope="row">'.$a++.'</th>
            <td hidden>'.$val[ID].'</td>
            <td>'.$val[Line].'</td>
            <td>'.$val[Create_By].'</td>
            <td>'.$val[Create_Date].'</td>
            <td>'.$val[Update_By].'</td>
            <td>'.$val[Update_Date].'</td>
            <td >
                <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
                        data-toggle="modal" data-target="#EditlineModal"  data-backdrop="static" onclick="SendLine_ID(\''.$val[ID].'\')" ><i class="fas fa-pen"></i></button>
                    <button type="button" class="btn-delete" onclick="Delline(\''.$val[ID].'\')""><i class="fas fa-trash-alt"></i></button>
                </div>
            </td>
        </tr>

    </tbody>';} ?>
</table> */

if($getdata <= 0) { echo '
    <div class="container text-center mt-5">
        Data Not Found!
    </div>
    ' ; } else { echo' <div class="table-wrapper">
    <table class="table table-bordered " style="margin:0px;">
        <thead class=" text-center thead-dark " style=" font-size: 12px;">
            <tr>
                <th scope="col">No.</th>
                <th scope="col">Line Name</th>
                <th scope="col">Create By</th>
                <th scope="col">Create Date</th>
                <th scope="col">Update By</th>
                <th scope="col">Update Date</th>
                <th scope="col">Tool</th>
            </tr>
        </thead>';
        ?>
        <?php $a = 1 ?>
        <?php foreach($getdata as $x => $val){
             $rowClass = ($a % 2 == 0) ? 'even-row' : 'odd-row';
            echo '<tbody class="text-center " style="font-size:14px;">   
   
   <tr class="' . $rowClass . '">
   <th scope="row">'.$a++.'</th>
   <td hidden>'.$val[ID].'</td>
   <td>'.$val[Line].'</td>
   <td>'.$val[Create_By].'</td>
   <td>'.$val[Create_Date].'</td>
   <td>'.$val[Update_By].'</td>
   <td>'.$val[Update_Date].'</td>
   <td class="col-1" >
       <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
               data-toggle="modal" data-target="#EditLineModal"  data-backdrop="static" onclick="SendLine_ID(\''.$val[ID].'\')" ><i class="fas fa-pen"></i></button>
           <button type="button" class="btn-delete" onclick="Delline(\''.$val[ID].'\')""><i class="fas fa-trash-alt"></i></button>
       </div>
   </td>
</tr>
</tbody>';}

echo '</div></table>';
    }
?>