<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


 $sql ="
 SELECT Distinct B.[Model] AS Model
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B
ON A.Model_Id = B.ID";

$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata);

?>