<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$sql = "
SELECT 
       [EF_Card] 
	   ,D.[Model] AS Model
      ,E.[Nijiko]  AS Nijiko
	  ,C.[Channel] AS Channel
	  ,[Sequence] 
	  ,[Sequence_Before] 
      ,[Actual_Torque]
      ,[Date]
      ,[Result]
  FROM [STT_DB].[IM].[SCREW_TQ_HISTORY] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Sequence] B
  ON A.SEQ_Id = B.ID 
  LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Channel] C
  ON B.Channel_Id = C.ID
   LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] D
  ON B.Model_Id = D.ID
   LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Nijiko] E
  ON B.Nijiko_Id = E.ID ORDER BY [Date] ASC ";

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

?>
<div class="table-wrapper" style="margin-Top:4rem; ">
    <table class="table table-bordered " style="margin:0px;">
        <thead class=" text-center thead-dark " style=" font-size: 12px;">
            <tr>
                <th scope=" col">No.</th>
                <th scope="col">EF_Card</th>
                <th scope="col">Model</th>
                <th scope="col">Nijiko</th>
                <th scope="col">Channel</th>
                <th scope="col">Seq</th>
                <th scope="col">Seq_Before</th>
                <th scope="col">Actual_Torque</th>
                <th scope="col">Date</th>
                <th scope="col">Result</th>
            </tr>
        </thead>

        <?php $a = 1 ?>
        <?php foreach($getdata as $x => $val)
    {echo '<tbody class="text-center " style="font-size:14px;" >
        <tr>
            <th >'.$a++.'</th>
            <td >'.$val[EF_Card].'</td>
            <td >'.$val[Model].'</td>
            <td  >'.$val[Nijiko].'</td>
            <td >'.$val[Channel].'</td>
            <td >'.$val[Sequence].'</td>
            <td >'.$val[Sequence_Before].'</td>
            <td >'.$val[Actual_Torque].'</td>
            <td >'.$val[Date].'</td>
            <td >'.$val[Result].'</td>
          
        </tr>

    </tbody>';} ?>
    </table>
</div>