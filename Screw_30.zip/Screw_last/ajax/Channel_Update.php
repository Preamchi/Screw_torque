<?php?>
<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Emp_ID = $_GET[Emp];
$Lastchannel_ID = $_GET[LastCH_ID];
$CH = $_GET[CH];
$PLC = $_GET[PLC];
$Station = $_GET[Station];
$Model = $_GET[New_Model];

$sql_check = "
SELECT * FROM [STT_DB].[IM].[SCREW_TQ_Channel] WHERE Channel = '$CH' AND Model_Id = '$Model' AND Station_Id = '$Station'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;


if($getdata == ''){
    
  $sql =" 
 
 UPDATE [STT_DB].[IM].[SCREW_TQ_Channel]
 SET [Channel] = '".$CH."'
    ,[PLC_Ref] = '".$PLC."'
    ,[Update_By] = '".$Emp_ID."'
    ,[Update_Date] = GETDATE()
WHERE ID = '".$Lastchannel_ID."'";

$myfunction->exec($sql); 
echo $sql;
      
     }else{
         echo 'have_data';
     }

/*   $sql =" 
 
 UPDATE [STT_DB].[IM].[SCREW_TQ_Channel]
 SET [Channel] = '".$CH."'
    ,[PLC_Ref] = '".$PLC."'
    ,[Model_Id] = '".$Model."'
    ,[Station_Id] = '".$Station."'
    ,[Update_By] = '".$Emp_ID."'
    ,[Update_Date] = GETDATE()
WHERE ID = '".$Lastchannel_ID."'";


$myfunction->exec($sql); 
print_r($sql); 
 */
?>