<?php?><?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = "
SELECT A.[ID]
      ,[Channel]
      ,A.[Station_Id]
      ,C.[Model] AS Model
      ,B.[Station] AS StationName
      ,D.[Line] AS Line
      ,[PLC_REF]
      ,A.[Update_By] AS UpdateBy
      ,A.[Create_By] AS CreateBy
      ,CONVERT(varchar,A.[Create_Date],120) AS Create_Date
      ,CONVERT(varchar,A.[Update_Date],120) AS Update_Date
      
  FROM [STT_DB].[IM].[SCREW_TQ_Channel] A
  LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] B 
  ON A.Station_Id = B.ID 
  LEFT JOIN 
  [STT_DB].[IM].[SCREW_TQ_Model] C
  ON A.Model_Id = C.ID 
  LEFT JOIN 
  [STT_DB].[IM].[SCREW_TQ_Line] D
  ON C.Line_Id = D.ID 
  ORDER BY A.[Update_Date] ASC ";

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

/* ?>


<table class="table" style="width: -webkit-fill-available;">
    <thead class="text-center">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Channel Name</th>
            <th scope="col">Station Name</th>
            <th scope="col">PLC_REF</th>
            <th scope="col">Update By</th>
            <th scope="col">Create Date</th>
            <th scope="col">Update Date</th>
            <th scope="col">Tool</th>
        </tr>
    </thead>

    <?php $a = 1 ?>
    <?php foreach($getdata as $x => $val){echo '<tbody class="text-center ">
        <tr>
            <th scope="row">'.$a++.'</th>
            <td hidden>'.$val[CH_ID].'</td>
            <td>'.$val[Channel_Name].'</td>
            <td>'.$val[StationName].'</td>
            <td>'.$val[PLC_REF].'</td>
            <td>'.$val[Update_By].'</td>
            <td>'.$val[Create_Date].'</td>
            <td>'.$val[Update_Date].'</td>
            <td >
                <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
                        data-toggle="modal" data-target="#editchannelModal"  data-backdrop="static" onclick="Send_id(\''.$val[CH_ID].'\'),load_part2(),load_cart2()" ><i class="fas fa-pen"></i></button>
                    <button type="button" class="btn-delete"  onclick="Delete(\''.$val[CH_ID].'\')""><i class="fas fa-trash-alt"></i></button>
                </div>
            </td>
        </tr>

    </tbody>';} ?>
</table> */

if($getdata <= 0) { echo '
    <div class="container text-center mt-5">
        Data Not Found!
    </div>
    ' ; } else { echo' <div class="table-wrapper">
    <table class="table table-bordered " style="margin:0px;">
        <thead class=" text-center thead-dark " style=" font-size: 12px;">
            <tr>
                <th scope="col">No.</th>
                <th scope="col">Channel Name</th>
                <th scope="col">Model</th>
                <th scope="col">Station </th>
                <th scope="col">Line</th>
                <th scope="col">PLC_REF</th>
                <th scope="col">Create By</th>
                <th scope="col">Create Date</th>
                <th scope="col">Update By</th>
                <th scope="col">Update Date</th>
                <th scope="col">Tool</th>
            </tr>
        </thead>';
        ?>
        <?php $a = 1 ?>
        <?php foreach($getdata as $x => $val){
               $rowClass = ($a % 2 == 0) ? 'even-row' : 'odd-row';
               echo '<tbody class="text-center " style="font-size:14px;">  
   <tr class="' . $rowClass . '">
   <th scope="row">'.$a++.'</th>
   <td hidden>'.$val[ID].'</td>
   <td>'.CH.''.$val[Channel].'</td>
   <td>'.$val[Model].'</td>
   <td>'.$val[StationName].'</td>
   <td>'.$val[Line].'</td>
   <td>'.$val[PLC_REF].'</td>
   <td>'.$val[CreateBy].'</td>
   <td>'.$val[Create_Date].'</td>
   <td>'.$val[UpdateBy].'</td>
   <td>'.$val[Update_Date].'</td>
   <td class="col-1" >
       <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
               data-toggle="modal" data-target="#EditChannelModal"  data-backdrop="static" onclick="Send_ID(\''.$val[ID].'\')" ><i class="fas fa-pen"></i></button>
           <button type="button" class="btn-delete"  onclick="Delete(\''.$val[ID].'\')""><i class="fas fa-trash-alt"></i></button>
       </div>
   </td>
</tr>
</tbody>';}

echo '</table>';
    }
?>