<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();



$ST_ID = $_GET[Station_id]; 
$Model = $_GET[Model_name]; 

$sql ="
SELECT 
A.[ID] AS ID
,[Nijiko] 
, B.[ID] AS ST_ID
, [Station]
FROM [STT_DB].[IM].[SCREW_TQ_Nijiko] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] B 
ON A.Station_Id = B.ID
WHERE B.ID = '$ST_ID' ";

/* $sql = "
SELECT [ID]
      ,[Nijiko]
  FROM [STT_DB].[IM].[SCREW_TQ_Nijiko]";SELECT 
 A.[ID] AS ID
,[Nijiko] 
, B.[Station_Id] AS ST_ID
FROM [STT_DB].[IM].[SCREW_TQ_Nijiko] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B 
ON A.Station_Id = B.Station_Id
 */

$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata)

?>