<?php?>
<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$CH_ID = $_GET[Channel_ID];

$sql=" 
DELETE [STT_DB].[IM].[SCREW_TQ_Channel] WHERE ID = '$CH_ID'";
$myfunction->exec($sql);
echo($sql);
die();
?>