<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Model = $_GET[Model]; 
$Station = $_GET[Station]; 


$sql = "
SELECT 
    A.ID AS Model_ID
    ,B.[ID] AS Line_ID
    ,B.[Line] AS Line
FROM [STT_DB].[IM].[SCREW_TQ_Model] A
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Line] B 
ON A.[Line_Id] = B.ID
WHERE A.Model = '$Model' AND A.Station_Id = '$Station'";

$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

 echo json_encode($getdata) 

?>