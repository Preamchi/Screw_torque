<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Model = $_GET[Model]; 

 $sql = "
 SELECT DISTINCT B.[Station] AS Station,
 A.[Station_Id] AS ST_ID
 FROM [STT_DB].[IM].[SCREW_TQ_Model] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] B 
 ON A.[Station_Id] = B.ID WHERE A.Model = '$Model'";

$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

 echo json_encode($getdata) 

?>