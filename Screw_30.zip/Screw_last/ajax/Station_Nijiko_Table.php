<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = "
SELECT [ID]
      ,[Model]+'-'+[Line]+'-'+[Process]+'-'+[Station] as Station_Name 
      ,[Nijiko_Name]
      ,[Part_No]
      ,[Part_Qty]
      ,[Scan_Status]
      ,[Update_By]
      ,[Scan_Date]  = CONVERT(varchar,[Scan_Date],120)
  FROM [STT_DB].[IM].[TBL_ScrewDV_Log_StationNijiko]";

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

?>


<table class="table" style="width: -webkit-fill-available;">
    <thead class="text-center">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Nijiko Name</th>
            <th scope="col">Station </th>
            <th scope="col">Part No</th>
            <th scope="col">Part Qty</th>
            <th scope="col">Scan In / Out</th>
            <th scope="col">Update By</th>
            <th scope="col">Update Date</th>
        </tr>
    </thead>

    <?php $a = 1 ?>
    <?php foreach($getdata as $x => $val){echo '<tbody class="text-center ">
        <tr>
            <th scope="row">'.$a++.'</th>
            <td hidden>'.$val[ID].'</td>
            <td>'.$val[Station_Name].'</td>
            <td>'.$val[Nijiko_Name].'</td>
            <td>'.$val[Part_No].'</td>
            <td>'.$val[Part_Qty].'</td>
            <td>'.$val[Scan_Status].'</td>
            <td>'.$val[Update_By].'</td>
            <td>'.$val[Scan_Date].'</td>
        </tr>

    </tbody>';} ?>
</table>