<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Emp_ID = $_GET[Emp];
$L_ID = $_GET[Line_ID];
$New_Line = $_GET[New_line];


$sql_check = "
SELECT [Line] FROM [STT_DB].[IM].[SCREW_TQ_Line] WHERE Line = '$New_Line'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;



if($getdata == ''){
    
$sql =" 
 UPDATE [STT_DB].[IM].[SCREW_TQ_Line]
 SET [Line] = '".$New_Line."'
    ,[Update_By] = '".$Emp_ID."'
    ,[Update_Date] = GETDATE()
WHERE ID = '".$L_ID."'";
$myfunction->exec($sql); 
    echo $sql;
         
    }else{
        echo 'have_data';
    }
        


/*  $sql =" 
 UPDATE [STT_DB].[IM].[SCREW_TQ_Line]
 SET [Line] = '".$New_Line."'
    ,[Update_By] = '".$Emp_ID."'
    ,[Update_Date] = GETDATE()
WHERE ID = '".$L_ID."'";
$myfunction->exec($sql); 
 */

?>