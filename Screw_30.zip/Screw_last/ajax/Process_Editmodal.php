<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Process_ID = $_GET[Process_Id];
/* 
$sql = "
SELECT 
  --A.*,
    --C.*,
	 --D.*
	A.[ID]
      ,[Sequence]
      ,[Sequence_Before]
      ,[Torque]
      ,[Torque_Max]
      ,[Torque_Min]
	  ,[Channel_Id]
	  ,B.[Model]
      ,C.[Station] AS Station
      ,D.[Nijiko] 
	  ,A.[Create_By]
      ,CONVERT(varchar,A.[Create_Date],120) AS Create_Date
      ,A.[Update_By] 
      ,CONVERT(varchar,A.[Update_Date],120) AS Update_Date
  FROM [STT_DB].[IM].[SCREW_TQ_Sequence] A
  LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Model] B
	ON A.Model_Id = B.ID
    LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Station] C
	ON B.Station_Id = C.ID
LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Nijiko] D
	ON A.Nijiko_Id = D.ID"; 
  */
    
$sql = "
SELECT 
A.[ID]
  ,[Sequence]
  ,[Sequence_Before]
  ,[Torque]
  ,[Torque_Max]
  ,[Torque_Min]
  ,A.[Model_Id] AS Model_Id
  ,F.[Channel] AS Channel
  ,B.[Model]+' ('+ D.[Station]+') '+ E.[Line] AS Station_Detail
  ,C.[Nijiko] AS Nijiko
  ,A.[Nijiko_Id] AS Nijiko_Id
  ,D.[ID] AS Station_Id
  
FROM [STT_DB].[IM].[SCREW_TQ_Sequence] A
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Model] B
ON A.Model_Id = B.ID
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Nijiko] C
ON A.Nijiko_Id = C.ID
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Station] D
ON B.Station_Id  = D.ID
 LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Line] E
ON B.Line_Id  = E.ID
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Channel] F
ON A.Channel_Id  = F.ID
  WHERE A.ID = '$Process_ID'"; 
 


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data = $val;
}

$data_process = json_encode($data);
    echo $data_process;

    
 
?>