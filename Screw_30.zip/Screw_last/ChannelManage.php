<?php
include "connect/COMMON.php";
include "ajax/Head.php";
?>

<link href="css/Allpage.css" rel="stylesheet" />

<body>
    <?php require 'component/Tab.php';?>

    <!------------------------------------ Channel Manage ------------------------------------------>
    <div class="layout">
        <div class="container" id="main">
            <div class="card "
                style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; padding-right: 14px; ">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">
                        <i class="fas fa-grip-horizontal"></i>
                        <label class="text">Channel Manage</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end; margin-right: 1.2rem;">
                        <button type="button" class="btn-add" data-backdrop="static" data-toggle="modal"
                            data-target="#AddChannelModal" onclick="Model_Value()">
                            <i class="fas fa-plus-circle"></i>&nbsp; Add Data
                        </button>
                    </div>
                    <!-- data table -->
                    <div id="show_channel"></div>
                </div>
            </div>
        </div>

        <!------------------------------------ All Modal ------------------------------------------>
        <!-- Modal Add -->
        <div class="modal fade" id="AddChannelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-plus-circle"></i>&nbsp;Add
                            Channnel
                        </h5>
                    </div>
                    <div class="modal-body p-5">
                        <!-- employee_id of user log in -->
                        <input id="emp" value="<?php echo $emp; ?>" hidden />
                        <form id="addchannel">
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">

                                    <label class="input-group-text " style="width: 90px;"
                                        for="inputGroupSelect01">Model</label>
                                </div>
                                <select class="custom-select " id="model_loop" onchange="Station_Where(this.value)">
                                </select>
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 90px;">Station</label>
                                </div>
                                <select class="custom-select " id="station_loop" onchange="Line_Where(this.value)">
                                </select>
                            </div>
                            <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 90px;">Line</label>
                                </div>
                                <select class="custom-select " id="line_loop" onchange="(this.value)">
                                </select>
                            </div>
                            <div class="d-flex flex-row ">
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Channel
                                        </span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="chname_input">
                                </div>
                                <div class="input-group input-group-sm mb-3 ml-3">
                                    <div class="input-group-prepend text-center">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90 px;">PLC_REF</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="plc_input">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                            onclick="Clear_Channel()">Cancel</button>
                        <button type="button" class="btn btn-success" onclick="Add_Channel()">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Edit -->
        <input id="channel_id" hidden />
        <div class="modal fade" id="EditChannelModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-pen"></i>&nbsp;Edit Channel
                        </h5>
                    </div>
                    <div class="modal-body p-5">
                        <form>
                            <!-- employee_id of user log in -->
                            <input id="emp" value="<?php echo $emp; ?>" hidden />

                            <form>

                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Model</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="model_data" disabled>
                                </div>
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Station</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="station_data" disabled>
                                </div>
                                <div class="input-group input-group-sm mb-3 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-sm"
                                            style="width: 90px;">Line</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Sizing example input"
                                        aria-describedby="inputGroup-sizing-sm" id="line_data" disabled>
                                </div>
                                <!-- <input id="model_data1" hidden /> -->

                                <!-- <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 112px;" for="inputGroupSelect01">New
                                        Model</label>
                                </div>
                                <select class="custom-select " id="model_loop1" onchange="Station_value1(this.value)">
                                </select>
                </div> -->

                                <!--      <label>Station:&nbsp;</label><input type="text" id="station_data1"
                                style="border:none; background:none; " disabled /><input id="station_id" hidden /> -->

                                <!--   <div class="input-group input-group-sm mb-3">
                                <div class="input-group-prepend">
                                    <label class="input-group-text " style="width: 112px;" for="inputGroupSelect01">New
                                        Station</label>
                                </div>
                                <select class="custom-select " id="station_loop1" onchange="(this.value)">
                                </select>
                            </div> -->
                                <div class="d-flex flex-row ">
                                    <div class="input-group input-group-sm mb-3 ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroup-sizing-sm"
                                                style="width: 90px;">Channel
                                            </span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Sizing example input"
                                            aria-describedby="inputGroup-sizing-sm" id="chname_data">
                                    </div>
                                    <div class="input-group input-group-sm mb-3 ml-3">
                                        <div class="input-group-prepend text-center">
                                            <span class="input-group-text" id="inputGroup-sizing-sm"
                                                style="width: 90 px;">PLC_REF</span>
                                        </div>
                                        <input type="text" class="form-control" aria-label="Sizing example input"
                                            aria-describedby="inputGroup-sizing-sm" id="plc_data">
                                    </div>
                                </div>
                            </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-success" onclick="Update_Channel()">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <?php require 'component/Footer.php';?>

        <!--------------------------- Script Function And JS File ---------------------------------->

        <!-- Load data func. -->
        <script>
        $(document).ready(function() {
            Load_Channel();
        });
        </script>

        <script>
        function Load_Channel() {
            document.getElementById("show_channel").innerHTML =
                '<div class="center"><span class="loader"></span></div>';

            setTimeout(function() {
                $.ajax({
                    url: "ajax/Channel_Table.php",
                    async: false,
                    cache: false,

                    success: function(result) {
                        document.getElementById("show_channel").innerHTML = result;
                    }
                });
            }, 1000);
        }
        </script>

        <!-- Clear form add func. -->
        <script>
        function Clear_Channel() {
            $("#addchannel").trigger("reset");
            /*   document.getElementById("station_loop").value = "0";
              document.getElementById("model_loop").value = "0";
              document.getElementById("line_loop").value = "0"; */
        }
        </script>

        <script>
        function Line_Where(e) {

            var model = document.getElementById('model_loop').value;
            document.getElementById("station_loop").value = e;
            var station = e;
            /*     console.log(model);
             */
            $.ajax({
                url: "ajax/Line_Select.php",
                async: false,
                cache: false,
                data: {
                    Model: model,
                    Station: station
                },
                success: function(result) {

                    var myJson = JSON.parse(result);

                    var options =
                        "<select class='form-select' aria-label='Default select example' id='model_new' >";
                    options += "<option value='0' disabled selected>select....</option>";

                    for (let x in myJson) {

                        var id = myJson[x]['Line_ID'];
                        var model_id = myJson[x]['Model_ID'];
                        var name = myJson[x]['Line'];
                        options += "<option value='" + id + "' id = '" + model_id + "'>" + name +
                            "</option>";
                    }
                    options += '</select>';

                    document.getElementById("line_loop").innerHTML = options;

                }
            });
        }
        </script>

        <script>
        function Station_Where(e) {
            document.getElementById("model_loop").value = e;
            var model = e;
            /*     console.log(model);
             */
            $.ajax({
                url: "ajax/Station_Select.php",
                async: false,
                cache: false,
                data: {
                    Model: model
                },
                success: function(result) {

                    var myJson = JSON.parse(result);

                    var options =
                        "<select class='form-select' aria-label='Default select example' id='model_new' >";
                    options += "<option value='0' disabled selected>select....</option>";

                    for (let x in myJson) {

                        var id = myJson[x]['ST_ID'];
                        /* var model_id = myJson[x]['Model_ID']; */
                        var name = myJson[x]['Station'];
                        options += "<option value='" + id + "'>" + name + "</option>";
                    }
                    options += '</select>';

                    document.getElementById("station_loop").innerHTML = options;

                }
            });
        }
        </script>
        <script src="js/Add_Channel.js"></script>
        <script src="js/Update_Channel.js"></script>
        <script src="js/Del_Channel.js"></script>
        <!--  <script src="js/Select_Station.js"></script> -->
        <script src="js/Select_Model.js"></script>

</body>

</html>