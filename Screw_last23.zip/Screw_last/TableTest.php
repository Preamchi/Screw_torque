<?php

include "connect/COMMON.php";
include "ajax/Head.php";
if (!session_id()) { session_start(); }
ob_start(); 

/* User Login */
$admin_login = $_SESSION[Name];

?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">


<!-- <!DOCTYPE html>
<html>

<head>
    <title>List Management</title>
    <style>
    table {
        border-collapse: collapse;
        width: 50%;
    }

    th,
    td {
        border: 1px solid black;
        padding: 8px;
        text-align: left;
    }

    .delete-btn {
        background-color: #f44336;
        border: none;
        color: white;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        cursor: pointer;
    }
    </style>
</head>

<body>
    <h1>List Management</h1>

    <form id="myForm">
        <input type="text" id="inputItem" placeholder="Enter an item" required>
        <input type="text" id="in" placeholder="Enter an item" required>
        <button type="submit">Add</button>

        <button id="clearBtn">Clear List</button>
    </form>

    <table id="myTable">
        <thead>
            <tr>
                <th>No.</th>
                <th>Item</th>
                <th>Item2</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

    <script>
    // Get the form and table elements
    const form = document.getElementById('myForm');
    const table = document.getElementById('myTable');


    // Function to add a new item to the list
    function addItem(event) {
        event.preventDefault(); // Prevent form submission

        // Get the input value
        const input = document.getElementById('inputItem');
        const input1 = document.getElementById('in');
        const newItem = input.value.trim();
        const newItem = input1.value.trim();
        if (newItem !== '') {
            // Create a new row
            const newRow = document.createElement('tr');

            // Create cells for number, item, and action
            const numberCell = document.createElement('td');
            numberCell.textContent = table.rows.length;

            const itemCell = document.createElement('td');
            itemCell.textContent = newItem;

            const actionCell = document.createElement('td');
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.className = 'delete-btn';

            // Add event listener to delete button
            deleteButton.addEventListener('click', deleteItem);

            // Append cells to the row
            actionCell.appendChild(deleteButton);
            newRow.appendChild(numberCell);
            newRow.appendChild(itemCell);
            newRow.appendChild(actionCell);

            // Append row to the table
            table.querySelector('tbody').appendChild(newRow);

            // Clear the input field
            input.value = '';
        }
    }

    // Function to delete an item from the list
    function deleteItem(event) {
        const row = event.target.parentNode.parentNode; // Get the row
        row.parentNode.removeChild(row); // Remove the row

        // Update the number in each row
        const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
        for (let i = 0; i < rows.length; i++) {
            rows[i].getElementsByTagName('td')[0].textContent = i + 1;
        }
    }

    function clearList() {
        table.querySelector('tbody').innerHTML = '';
    }

    // Add event listener to the form
    form.addEventListener('submit', addItem);

    // Add event listener to the clear button
    clearBtn.addEventListener('click', clearList);
    // Add event listener to the form
    form.addEventListener('submit', addItem);
    </script>
</body>

</html> -->
<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>

<table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Position</th>
            <th>Office</th>
            <th>Age</th>
            <th>Start date</th>
            <th>Salary</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Tiger Nixon</td>
            <td>System Architect</td>
            <td>Edinburgh</td>
            <td>61</td>
            <td>2011-04-25</td>
            <td>$320,800</td>
        </tr>
        <tr>
            <td>Garrett Winters</td>
            <td>Accountant</td>
            <td>Tokyo</td>
            <td>63</td>
            <td>2011-07-25</td>
            <td>$170,750</td>
        </tr>
        <tr>
            <td>Ashton Cox</td>
            <td>Junior Technical Author</td>
            <td>San Francisco</td>
            <td>66</td>
            <td>2009-01-12</td>
            <td>$86,000</td>
        </tr>
        <tr>
            <td>Cedric Kelly</td>
            <td>Senior Javascript Developer</td>
            <td>Edinburgh</td>
            <td>22</td>
            <td>2012-03-29</td>
            <td>$433,060</td>
        </tr>
        <tr>
            <td>Airi Satou</td>
            <td>Accountant</td>
            <td>Tokyo</td>
            <td>33</td>
            <td>2008-11-28</td>
            <td>$162,700</td>
        </tr>
        <tr>
            <td>Brielle Williamson</td>
            <td>Integration Specialist</td>
            <td>New York</td>
            <td>61</td>
            <td>2012-12-02</td>
            <td>$372,000</td>
        </tr>
        <tr>
            <td>Herrod Chandler</td>
            <td>Sales Assistant</td>
            <td>San Francisco</td>
            <td>59</td>
            <td>2012-08-06</td>
            <td>$137,500</td>
        </tr>
        <tr>
            <td>Michael Bruce</td>
            <td>Javascript Developer</td>
            <td>Singapore</td>
            <td>29</td>
            <td>2011-06-27</td>
            <td>$183,000</td>
        </tr>
        <tr>
            <td>Donna Snider</td>
            <td>Customer Support</td>
            <td>New York</td>
            <td>27</td>
            <td>2011-01-25</td>
            <td>$112,000</td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <th>Name</th>
            <th>Position</th>
            <th>Office</th>
            <th>Age</th>
            <th>Start date</th>
            <th>Salary</th>
        </tr>
    </tfoot>
</table>