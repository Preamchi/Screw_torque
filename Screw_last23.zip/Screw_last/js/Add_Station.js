function Add_Station() {
   
    var employee = document.getElementById('emp').value;
    var st_name = document.getElementById('stname_input').value;   
   
    if ((!st_name) ){
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {

        $.ajax({
            type: "GET",
            url: "ajax/Station_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: employee,
                ST_Name : st_name,
    
            },
            success: function(result) {
                if (result == 'have_data'){
                    Swal.fire({
                        width: 400,
                        title: 'Add failed!',
                        text: 'User information already exists.',
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1700
                      });
                      document.getElementById("stname_input").value = '';
                }else{
                    Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500 
                  });
                  $('#AddStationModal').modal('hide');
                  $('.modal-backdrop').remove();
                  $("#addstation").trigger("reset");
                  Load_Station();
                }
            
     }
        });
       
    }
}
