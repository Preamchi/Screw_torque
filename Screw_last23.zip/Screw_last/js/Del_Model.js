function Delmodel(e) {

    var model_id = e;

 /*     console.log(model_id);
    $.ajax({
        type: "GET",
        url: "ajax/Model_Del.php",
        async: false,
        cache: false,
        data: {
            Model_id: model_id
        },
        success: function(result) {
            Swal.fire({
                width: 400,
                title: 'Delete Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
            });
            Load_Model();
        }

    }); */
 Swal.fire({
        title: 'Do you want to delete?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
        width: 400
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "GET",
                url: "ajax/Model_Del.php",
                async: false,
                cache: false,
                data: {
                    Model_id: model_id
                },
                success: function(result) {
                    Swal.fire({
                        width: 400,
                        title: 'Delete Successfully!',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1500
                    });
                    Load_Model();
                }
            });
        }
})
}

