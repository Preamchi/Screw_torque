function Add_Process() {
   
    var Emp = document.getElementById('emp').value;  
    var channel = document.getElementById('channel_select').value;
    var nijiko = document.getElementById('nijiko_select').value;
    var seq = document.getElementById('seq').value;
    var seq_before = document.getElementById('seq_before').value; 
    var select = document.getElementById("model_st_select");
    var selectedOption = select.options[select.selectedIndex];
    var model_id = selectedOption.id; 
    var input1 = parseFloat(document.getElementById("torque_max").value);
    var input2 = parseFloat(document.getElementById("torque").value);
    var input3 = parseFloat(document.getElementById("torque_min").value);

 /*    var torque = document.getElementById('torque').value; 
    var tq_max = document.getElementById('torque_max').value; 
    var tq_min = document.getElementById('torque_min').value;  */
/*     console.log(Emp, model_st,channel,nijiko,seq, seq_before, torque, tq_max,tq_min);  */



    if ((!seq ) || (!seq_before) || isNaN(input1) || isNaN(input2) || isNaN(input3) ) {

        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });

    } else if (!(input1 >= input2 && input2 >= input3)){
        Swal.fire({
            width: 400,
            title: 'Please enter values : max > medium > min.!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
       
    }else{
        $.ajax({
            type: "GET",
            url: "ajax/Process_Add.php",
            async: false,
            cache: false,
            data: {
                Employee : Emp,
                Model_St : model_id,
                Channel : channel,
                Nijiko : nijiko,
                Seq : seq,
                Seq_Before : seq_before,
                Torque_Max : input1,  
                Torque : input2, 
                Torque_Min :input3
               
            },
            success: function(result) {

                if(result == 'have_data'){
                    Swal.fire({
                        width: 400,
                        title: 'Add failed!',
                        text: 'User information already exists.',
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1500
                      });
                      document.getElementById("seq").value = '';
                      document.getElementById("seq_before").value = '';
                      document.getElementById("torque").value = '';
                      document.getElementById("torque_max").value = '';
                      document.getElementById("torque_min").value = '';
                      
                }else{
                  Swal.fire({
                    width: 400,
                    title: 'Update Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });

                $('#AddProcessModal').modal('hide');
                $('.modal-backdrop').remove();
                $("#AddProcess").trigger("reset");
               Load_Process(); 

                }
              
     }
        });
    }
}
