<?php

include "connect/COMMON.php";
include "ajax/Head.php";

?>

<link href="css/Allpage.css" rel="stylesheet" />



<!------------------------------------ body: screw page ------------------------------------------>

<body>
    <!-- Tab menu -->
    <?php require 'component/Tab.php';?>

    <div class="layout">
        <div class="container" id="main">
            <div class="card " style="wEmailidth:30rem; height:32rem; width:70rem; margin-bottom:2rem; ">
                <div class="card-body pt-0 pl-0">
                    <div class="topic">
                        <i class="fas fa-cog"></i>
                        <label class="text">Screw Manage</label>
                    </div>
                    <div style="  margin-top: 4rem; display: flex; justify-content:flex-end;  margin-right: 2rem;">
                        <button type="button" class="btn-add" data-toggle="modal" data-target="#AddScrewModal"
                            data-backdrop="static"><i class="fas fa-plus-circle"></i>&nbsp; Add Data
                        </button>
                    </div>
                    <!-- screw_data table -->
                    <div id="show_screw"></div>
                </div>
            </div>
        </div>
    </div>

    <!------------------------------------ all modal screw page ------------------------------------------>

    <!-- Modal Add -->
    <div class=" modal fade" id="AddScrewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">
                        <i class="fas fa-plus-circle"></i>&nbsp;Add Screw
                    </h5>
                </div>
                <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                <div class="modal-body p-4">
                    <form class="col" id="addscrew">
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" style="width: 100px;" id="inputGroup-sizing-sm">Part
                                    No</span>
                            </div>
                            <input type="number" class="form-control input-number-hide-spin-buttons"
                                aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm"
                                id="partno_input" placeholder="e.g. 428743601">
                        </div>
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" style="width: 100px;" id="inputGroup-sizing-sm">Screw
                                    Name</span>
                            </div>
                            <input type="text" class="form-control " aria-label="Sizing example input"
                                aria-describedby="inputGroup-sizing-sm" id="screwname_input">
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"
                        onclick="Clear_Form()">Cancel</button>
                    <button type="submit" class="btn btn-success" onclick="Add_Screw()">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit -->
    <input id="screw_id" hidden />
    <div class="modal fade" id="EditScrewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-pen"></i>&nbsp;Edit Screw</h5>
                </div>
                <input id="emp" value="<?php echo $emp; ?>" hidden /> <!-- employee_id of user log in -->
                <div class="modal-body p-4">
                    <form class="col ">
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" style="width: 100px;" id="inputGroup-sizing-sm">Part
                                    No</span>
                            </div>
                            <input type="number" class="form-control col-9  input-number-hide-spin-buttons"
                                aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm"
                                id="partno_data">
                        </div>
                        <div class="input-group input-group-sm mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" style="width: 100px;" id="inputGroup-sizing-sm">Screw
                                    Name</span>
                            </div>
                            <input type="text" class="form-control col-9" aria-label="Sizing example input"
                                aria-describedby="inputGroup-sizing-sm" id="screwname_data">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                    <button type=" button" class="btn btn-success" onclick="Update_Screw()"
                        data-dismiss="modal">Update</button>
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php require 'component/Footer.php';?>

    <!--------------------------- script function and JS file ---------------------------------->

    <!-- Load data func. -->
    <script>
    $(document).ready(function() {
        Load_Screw();
    });
    </script>

    <script>
    function Load_Screw() {
        document.getElementById("show_screw").innerHTML = '<div class="center"><span class="loader"></span></div>';

        setTimeout(function() {
            $.ajax({
                url: "ajax/Screw_Table.php",
                async: false,
                cache: false,

                success: function(result) {
                    document.getElementById("show_screw").innerHTML = result;
                }
            });
        }, 1000);
    }
    </script>

    <script>
    function Clear_Form() {
        $("#addscrew").trigger("reset");
    }
    </script>

    <script src="js/function/Add_Screw.js"></script>
    <script src="js/function/Update_Screw.js"></script>
    <script src="js/function/Del_Screw.js"></script>

</body>

</html>