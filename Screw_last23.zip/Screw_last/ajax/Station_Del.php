<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$ST_ID = $_GET[ST_ID];

$sql=" 
DELETE [STT_DB].[IM].[SCREW_TQ_Station]  WHERE ID = '$ST_ID'";
$myfunction->exec($sql);
die;
?>