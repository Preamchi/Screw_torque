<?php?><?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = "
SELECT [ID]
      ,[Nijiko_Name]
      ,[Part_No]
      ,[Part_Serial]
      ,[Use_Part]
      ,[Update_By]
      ,[Update_Date] = CONVERT(varchar,[Update_Date],120)
  FROM [STT_DB].[IM].[TBL_ScrewDV_Log_CartNijiko]";

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

?>


<table class="table" style="width: -webkit-fill-available;">
    <thead class="text-center">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Nijiko name</th>
            <th scope="col">Part No</th>
            <th scope="col">Part Serial</th>
            <th scope="col">Use Part Qty</th>
            <th scope="col">Update By</th>
            <th scope="col">Update Date</th>

        </tr>
    </thead>

    <?php $a = 1 ?>
    <?php foreach($getdata as $x => $val){echo '<tbody class="text-center ">
        <tr>
            <th scope="row">'.$a++.'</th>
            <td hidden>'.$val[ID].'</td>
            <td>'.$val[Nijiko_Name].'</td>
            <td>'.$val[Part_No].'</td>
            <td>'.$val[Part_Serial].'</td>
            <td>'.$val[Use_Part].'</td>
            <td>'.$val[Update_By].'</td>
            <td>'.$val[Update_Date].'</td>
        </tr>

    </tbody>';} ?>
</table>