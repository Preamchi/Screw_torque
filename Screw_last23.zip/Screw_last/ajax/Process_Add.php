<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Employee];
$Model = $_GET[Model_St];
$Nijiko = $_GET[Nijiko];
$Channel = $_GET[ Channel];
$Seq = $_GET[Seq];
$Seq_Before = $_GET[Seq_Before];
$Torq = $_GET[Torque];
$Torq_Max = $_GET[Torque_Max];
$Torq_Min = $_GET[Torque_Min];


$sql_check = "
SELECT 
     [Sequence]
	,[Model_Id]
  FROM [STT_DB].[IM].[SCREW_TQ_Sequence] WHERE Model_Id = '$Model' AND Sequence = '$Seq'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){
    
    $sql="
    INSERT INTO [STT_DB].[IM].[SCREW_TQ_Sequence]
    ([Sequence]
    ,[Sequence_Before]
    ,[Torque]
    ,[Torque_Max]
    ,[Torque_Min]
    ,[Channel_Id]
    ,[Model_Id]
    ,[Nijiko_Id]
    ,[Create_Date]
    ,[Create_By]
    ,[Update_Date]
    ,[Update_By])
    VALUES
    ('".$Seq."','".$Seq_Before."','".$Torq."','".$Torq_Max."','".$Torq_Min."','".$Channel."','".$Model."','".$Nijiko."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')";
$myfunction->exec($sql);
 echo $sql;
 
     
    }else{

        echo 'have_data';
    }
    

?>