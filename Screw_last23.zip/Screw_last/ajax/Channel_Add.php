<?php?>

<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp];
$Channel_Name = $_GET[Channel_Name];
$Station_ID = $_GET[station];
$PLC = $_GET[PLC];
$Model = $_GET[Model];


  $sql_check = "
  SELECT [ID]
  ,[Channel]
  ,[PLC_Ref]
  ,[Model_Id]
  ,[Station_Id]
  ,[Create_Date]
  ,[Create_By]
  ,[Update_Date]
  ,[Update_By]
FROM [STT_DB].[IM].[SCREW_TQ_Channel] WHERE Channel = '$Channel_Name' AND Station_Id = '$Station_ID' AND Model_Id = '$Model' AND PLC_Ref = '$PLC'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_check  ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){
    
    $sql="
    INSERT INTO [STT_DB].[IM].[SCREW_TQ_Channel]
               ([Channel]
               ,[PLC_Ref]
               ,[Model_Id]
               ,[Station_Id]
               ,[Create_Date]
               ,[Create_By]
               ,[Update_Date]
               ,[Update_By])
    VALUES('".$Channel_Name."','".$PLC."','".$Model."','".$Station_ID."',GETDATE(),'".$Emp_ID."',GETDATE(),'".$Emp_ID."')"; 
    $myfunction->exec($sql);
    echo $sql;
        
       }else{
           echo 'have_data';
       }
       
?>