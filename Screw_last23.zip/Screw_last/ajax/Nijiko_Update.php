<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Emp_ID = $_GET[Emp];
$N_ID = $_GET[Niji_ID];
$Nijiko = $_GET[Nijiko];
$Screw = $_GET[Screw];
$Station = $_GET[Station];



 $sql =" 
 UPDATE [STT_DB].[IM].[SCREW_TQ_Nijiko]
   SET [Nijiko] = '".$Nijiko."'
      ,[Station_Id] = '".$Station."'
      ,[Screw_Id] = '".$Screw."'
      ,[Update_By] = '".$Emp_ID."'
      ,[Update_Date] = GETDATE()
WHERE ID = '".$N_ID."'";

$myfunction->exec($sql); 


?>