<?php

if (!session_id()) { session_start(); }
ob_start();

session_start();
session_unset();
session_destroy();

// print_r ($_SESSION);
//exit();

?>
<!-- 
<i class="fas fa-sign-out-alt"></i> -->