<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


 $sql ="
 SELECT A.[ID] AS ID
 ,B.[ID] AS Model_ID
 ,B.[Model] AS Model
 ,C.[Station] AS Station 
FROM [STT_DB].[IM].[SCREW_TQ_Channel] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Model] B
ON A.Model_Id = B.ID
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] C
ON B.Station_Id = C.ID";

$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata);

?>