<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

/* $Model1 = 'LS'; */

$Model1 = $_GET[Model]; 

$sql = "
SELECT B.[Station] AS Station,
A.[Station_Id] AS ST_ID, A.[ID] AS Model_ID
FROM [STT_DB].[IM].[SCREW_TQ_Model] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] B 
ON A.[Station_Id] = B.ID WHERE A.Model = '$Model1'";


$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

 echo json_encode($getdata) 

?>