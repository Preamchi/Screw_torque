<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Process_ID = $_GET[Process_Id];

$sql = "
SELECT 
  --A.*,
    --B.*,
    --C.*,
	 --D.*
	A.[ID]
      ,[Sequence]
      ,[Sequence_Before]
      ,[Torque]
      ,[Torque_Max]
      ,[Torque_Min]
	  ,B.[Channel] AS Channel
	  ,C.[Model]
      ,D.[Nijiko] AS
  FROM [STT_DB].[IM].[SCREW_TQ_Sequence] A
  LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Channel] B
    ON A.Channel_Id = B.ID
 LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Model] C
	ON A.Model_Id = C.ID
LEFT JOIN 
    [STT_DB].[IM].[SCREW_TQ_Nijiko] D
	ON A.Nijiko_Id = D.ID
    WHERE A.ID = '$Process_ID'"; 
 


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data = $val;
}

$data_process = json_encode($data);
    echo $data_process;

    
 
?>