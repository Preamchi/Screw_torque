<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Emp_ID = $_GET[Emp_ID];


$sql=" DELETE [STT_DB].[IM].[TBL_ScrewDV_Pm_User] WHERE Emp_ID = '$Emp_ID'";
$myfunction->exec($sql);
die;
?>