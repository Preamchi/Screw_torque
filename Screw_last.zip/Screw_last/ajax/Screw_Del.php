<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Screw_ID = $_GET[Screw_id];


$sql=" DELETE FROM [STT_DB].[IM].[SCREW_TQ_ScrewType] WHERE ID = '$Screw_ID'";
$myfunction->exec($sql);


?>