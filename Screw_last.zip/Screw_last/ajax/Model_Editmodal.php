<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Model_ID = $_GET[Model_ID];

$sql=
"SELECT 
--A.*,
--B.*,
--C.*
A.[ID]
,A.[Model] AS Model
,B.[Station] AS Station
,C.[Line] AS LineName
,C.[ID] AS LineID
,B.[ID] AS ST_ID

FROM 
[STT_DB].[IM].[SCREW_TQ_Model] A
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Station] B
ON A.[Station_Id] = B.[ID]
LEFT JOIN
[STT_DB].[IM].[SCREW_TQ_Line] C
ON A.[Line_Id] = C.[ID]
WHERE A.ID = '$Model_ID'";



 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_channel = $val;
}

$data_channel1 = json_encode($data_channel);
    echo $data_channel1;

    
 
?>