<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql=
"SELECT 
--A.*,
--B.*,
--C.*
A.[ID]
,A.[Model]
,B.[Station]
,C.[Line]
,CONVERT(varchar,A.[Create_Date],120) AS Create_Date
,A.[Create_By]
,A.[Update_By],
CONVERT(varchar,A.[Update_Date],120) AS Update_Date
FROM 
[STT_DB].[IM].[SCREW_TQ_Model] A
LEFT JOIN 
[STT_DB].[IM].[SCREW_TQ_Station] B
ON
A.[Station_Id] = B.[ID]
LEFT JOIN
[STT_DB].[IM].[SCREW_TQ_Line] C
ON
A.[Line_Id] = C.[ID]";

/* $sql ="
SELECT [ID]
      ,[Model]
      ,[Station_Id]
      ,[Line_Id]
      ,[Create_Date] = CONVERT(varchar, [Create_Date],120)
      ,[Create_By]
      ,[Update_Date] = CONVERT(varchar, [Update_Date],120)
      ,[Update_By]
  FROM [STT_DB].[IM].[SCREW_TQ_Model] ORDER BY [Update_Date] ASC ";

 */

/* $sql = "
SELECT [Model_ID]
,[Model_Name]
,[Update_By]
,[Create_Date] = CONVERT(varchar,[Create_Date],120)
,[Update_Date]  = CONVERT(varchar, [Update_Date],120)
FROM [STT_DB].[IM].[TBL_ScrewDV_Model] ORDER BY [Update_Date] ASC ";
 */
$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

/* ?>


<table class="table" style="width: -webkit-fill-available;">
    <thead class="text-center">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Model Name</th>
            <th scope="col">Station</th>
            <th scope="col">Line</th>
            <th scope="col">Create By</th>
            <th scope="col">Create Date</th>
            <th scope="col">Update By</th>
            <th scope="col">Update Date</th>
            <th scope="col">Tool</th>
        </tr>
    </thead>

    <?php $a = 1 ?>
    <?php foreach($getdata as $x => $val){echo '<tbody class="text-center ">
        <tr>
            <th scope="row">'.$a++.'</th>
            <td hidden>'.$val[ID].'</td>
            <td>'.$val[Model].'</td>
            <td>'.$val[Station].'</td>
            <td>'.$val[Line].'</td>
            <td>'.$val[Create_By].'</td>
            <td>'.$val[Create_Date].'</td>
            <td>'.$val[Update_By].'</td>
            <td>'.$val[Update_Date].'</td>
            <td >
                <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
                        data-toggle="modal" data-target="#editcartModal"  data-backdrop="static" onclick="Send_ID(\''.$val[ID].'\')" ><i class="fas fa-pen"></i></button>
                    <button type="button" class="btn-delete" onclick="Delmodel(\''.$val[ID].'\')""><i class="fas fa-trash-alt"></i></button>
                </div>
            </td>
        </tr>

    </tbody>';} ?>
</table> */

if($getdata <= 0) { echo '
    <div class="container text-center mt-5">
        Data Not Found!
    </div>
    ' ; } else { echo' <table class="table" style="width: -webkit-fill-available;">
    <thead class="text-center">
        <tr>
            <th scope="col">No.</th>
            <th scope="col">Model</th>
            <th scope="col">Station</th>
            <th scope="col">Line</th>
            <th scope="col">Create By</th>
            <th scope="col">Create Date</th>
            <th scope="col">Update By</th>
            <th scope="col">Update Date</th>
            <th scope="col">Tool</th>
        </tr>
    </thead>';
    ?>
    <?php $a = 1 ?>
    <?php foreach($getdata as $x => $val){echo '<tbody class="text-center ">   
   
   <tr>
   <th scope="row">'.$a++.'</th>
   <td hidden>'.$val[ID].'</td>
   <td>'.$val[Model].'</td>
   <td>'.$val[Station].'</td>
   <td>'.$val[Line].'</td>
   <td>'.$val[Create_By].'</td>
   <td>'.$val[Create_Date].'</td>
   <td>'.$val[Update_By].'</td>
   <td>'.$val[Update_Date].'</td>
   <td >
       <div class="d-flex flex-row justify-content-between "> <button type="button" class="btn-edit"
               data-toggle="modal" data-target="#EditmodelModal"  data-backdrop="static" onclick=" Send_model(\''.$val[ID].'\'),Station_value1(),Line_value1()" ><i class="fas fa-pen"></i></button>
           <button type="button" class="btn-delete" onclick="Delmodel(\''.$val[ID].'\')""><i class="fas fa-trash-alt"></i></button>
       </div>
   </td>
</tr>
</tbody>';}

echo '</table>';
    }
?>