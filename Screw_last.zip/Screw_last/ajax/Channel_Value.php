<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$sql = " 
SELECT  [ID],[Channel] FROM [STT_DB].[IM].[SCREW_TQ_Channel] ";


$getdata = '';
$myfunction->result_array = '';
$myfunction->getdb($sql ,'mssql');
$getdata = $myfunction->result_array;

echo json_encode($getdata)
/* 
 foreach($getdata as $x => $val) {
    $data_cart[$val[ID]] = $val;
}


 $data_cart1 = json_encode($data_cart);
   print_r ($data_cart1); 
    
 */
?>