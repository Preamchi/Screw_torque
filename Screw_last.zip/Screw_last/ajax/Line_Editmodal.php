<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Line_ID = $_GET[Line_Id];

$sql = " 
SELECT [ID],[Line] FROM [STT_DB].[IM].[SCREW_TQ_Line] WHERE ID = '$Line_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_line= $val;
}

$data_line1 = json_encode($data_line);
    echo $data_line1;
  
    
 
?>