<?php 
if (!session_id()) {
    session_start();

}ob_start();

session_start();


$emp = $_SESSION[Name];

if (!isset($_SESSION['NAME'])) {

    header('Location:index.php');
    die;

}?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Screw.Torque</title>

    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />

    <script src='js/jquery.js'></script>

    <!-- Script BS-->
    <script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="js/jquery.slim.min.js"></script>
    <script type="text/javascript" src='js/jquery.min.js'></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/sweetalert2@11.js"></script>
    <script type="text/javascript" src="js/bootstrap4-toggle.min.js"></script>
    <script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>



    <!-- Font Awesome ver. 5.15.4 -->
    <link rel="stylesheet" href="assets/fontawesome-free-5.15.4-web/css/all.min.css">
    <link href="css/bootstrap/bootstrap4-toggle.min.css" rel="stylesheet" />
    <link href="css/bootstrap/bootstrap.min.css" rel="stylesheet" />
    <link href="css/bootstrap/dataTables.bootstrap4.min.css" rel="stylesheet" />
    <script type="text/javascript" src="js/Logout.js"></script>


    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/Tab.css" rel="stylesheet" />
</head>


</html>