<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();

$Admin_ID = $_GET[Admin];
$Employee_ID = $_GET[Emp];
$Emp_name = $_GET[Emp_name];
$Emp_Role = $_GET[Emp_role];



$sql_search = "
SELECT [Emp_ID] FROM [STT_DB].[IM].[TBL_ScrewDV_Pm_User] WHERE [Emp_ID] = '$Employee_ID'"; 

$getdata = '';
$myfunction->result_array = '';
$myfunction-> getdb($sql_search ,'mssql');
$getdata = $myfunction->result_array;

if($getdata == ''){

$sql = "
INSERT INTO [STT_DB].[IM].[TBL_ScrewDV_Pm_User]
([Emp_ID]
,[Emp_Name]
,[Emp_Role]
,[Update_By]
,[Create_Date]
,[Update_Date])
VALUES ('".$Employee_ID."','".$Emp_name."','".$Emp_Role."','".$Admin_ID."',GETDATE(),GETDATE())"; 
 $myfunction->exec($sql);
 echo $sql;
 
}else{
    echo 'have_user';
}


?>