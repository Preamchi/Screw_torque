<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Employee = $_GET[Emp];
$Screw_ID = $_GET[Screw_ID];
$Part_No = $_GET[Part_No];
$Screw_Name = $_GET[Screw_Name];


 $sql =" UPDATE [STT_DB].[IM].[SCREW_TQ_ScrewType] SET Part_No = '".$Part_No."',Screw_Name = '".$Screw_Name."',Update_By = '".$Employee."',Update_Date = GETDATE()
WHERE ID = '".$Screw_ID."'";
$myfunction->exec($sql); 


?>