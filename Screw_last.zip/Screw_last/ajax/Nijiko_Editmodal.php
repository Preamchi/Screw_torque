<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Nijiko_ID = $_GET[Nijiko_ID];


$sql = " 
SELECT A.[ST_ID],[Machine_ID],[Nijiko_Name],[Part_No],B.[Model]+'-'+B.[Line]+'-'+B.[Process]+'-'+B.[Station] as Station_Name ,A.[Update_By],A.[Create_Date],A.[Update_Date] 
FROM [STT_DB].[IM].[TBL_ScrewDV_Pm_Nijiko] A LEFT JOIN  [STT_DB].[IM].[TBL_ScrewDV_Pm_Station] B 
ON A.ST_ID = B.ST_ID WHERE [Machine_ID] = '$Nijiko_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_channel = $val;
}

$data_channel1 = json_encode($data_channel);
    echo $data_channel1;

    
 
?>