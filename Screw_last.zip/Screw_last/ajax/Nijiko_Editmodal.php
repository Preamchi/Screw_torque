<?php
include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'IM';
$myfunction->password = 'Im@SttMFD';
$myfunction->CnndB();


$Nijiko_ID = $_GET[Nijiko_ID];


$sql = " 
SELECT A.[ID]
,[Nijiko]
,A.[Screw_Id] AS Screw_Id
,A.[Station_Id] AS Station_Id
,C.[Station] As Station
,B.[Screw_Name] AS Screw
,CONVERT(varchar,A.[Create_Date],120) AS Create_Date
,A.[Create_By]
 ,CONVERT(varchar,A.[Update_Date],120) AS Update_Date
,A.[Update_By]
FROM [STT_DB].[IM].[SCREW_TQ_Nijiko] A LEFT JOIN [STT_DB].[IM].[SCREW_TQ_ScrewType] B
ON A.Screw_Id = B.ID 
LEFT JOIN [STT_DB].[IM].[SCREW_TQ_Station] C
ON A.Station_Id = C.ID WHERE A.[ID] = '$Nijiko_ID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 foreach($getdata as $x => $val) {
    $data_channel = $val;
}

$data_channel1 = json_encode($data_channel);
    echo $data_channel1;

    
 
?>