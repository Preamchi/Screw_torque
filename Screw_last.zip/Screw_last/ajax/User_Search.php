<?php

include "../connect/COMMON.php";
$myfunction = new suchin_class();
$myfunction->host = '43.72.52.25';
$myfunction->user = 'EMS';
$myfunction->password = 'Ems@SttMFD';
$myfunction->CnndB();

$GID = $_GET[search];

$sql = "
SELECT 
[EMP_GID]
,[EMP_ID]
,[EMP_NAME_EN]
,[DEPARTMENT_NAME]
,[DIVISION_NAME]
FROM [EMS].[EMS].[Employee] WHERE EMP_GID = '$GID' OR EMP_ID  = '$GID'";


 $getdata = '';
 $myfunction->result_array = '';
 $myfunction-> getdb($sql ,'mssql');
 $getdata = $myfunction->result_array;


 if( $getdata == ''){
    echo  'no';

}else{
   
    foreach($getdata as $x => $val) {
    $data_user = $val; 
    
    $data = json_encode($data_user);
    echo ($data);
    }
   
} 


?>