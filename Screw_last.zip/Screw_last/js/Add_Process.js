function Add_Process() {
   
    var Emp1 = document.getElementById('emp').value;
    var ch = document.getElementById('channel_loop').value;  
    var model= document.getElementById('model_loop').value;
    var niji = document.getElementById('nijiko_loop').value;
    var seq = document.getElementById('seq1').value;
    var seq_before = document.getElementById('seq_before').value; 
    var Tq1 = document.getElementById('torq').value; 
    var Tq_max = document.getElementById('torq_max').value; 
    var Tq_min = document.getElementById('torq_min').value;   

    console.log(Emp1, ch,model,niji,seq, seq_before,Tq1,Tq_max,Tq_min);
    if ((!ch) || (!model)  ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Process_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: Emp1,
                CH: ch,
                Model: model,
                Nijiko: niji,
                Seq: seq,
                Seq_b: seq_before,
                Tq: Tq1,
                Tq_Min: Tq_min,
                Tq_Max: Tq_max,
            },
            success: function(result) {
            
               Swal.fire({
                    width: 400,
                    title: 'Update Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });

                $('#AddProcessModal').modal('hide');
                $('.modal-backdrop').remove();
                load_process(); 
     }
        });
    }
}
