$('#logout').click(function(){
    Swal.fire({
        title: 'Are you sure to log out?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "GET",
                url: "ajax/Logout.php",
                async: false,
                cache: false,

                success: function(result) {
                    Swal.fire({
                        width: 400,
                        title: 'Logout Successfully!',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                      })
                      window.location.href = "index.php";
                } 
           
            });
        }
      })
 
}); 

/* Swal.fire({
        title: 'Are you sure to logout?',
        text: "",
        type: 'warning',
        buttons:{
            confirm: {
                text : 'Yes',
                className : 'btn btn-success'
            },
            cancel: {
                visible: true,
                className: 'btn btn-danger'
            }
        }
    }).then((yes_logout) => {
        if (yes_logout) {
            $.ajax({
                type: "GET",
                url: "ajax/Logout.php",
                async: false,
                cache: false,
                success: function(result) {
                    window.open("./","_self");
                } 
            });
        } else {
            swal.close();
        }
    });  */