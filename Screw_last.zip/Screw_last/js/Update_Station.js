
function Send_ID(e) {
    
    document.getElementById("id_station").value = e;
    var st_id = e;

    $.ajax({
        type: "GET",
        url: "ajax/Station_Editmodal.php",
        async: false,
        cache: false,
        data: {
            ST_ID : st_id
        },

        success: function(result) {
       
            const myJson = JSON.parse(result);
            document.getElementById("station_data1").value = myJson.Station;


   
        }
    });

   
}
function Update() {
    var emp = document.getElementById('emp').value;
    var st_id = document.getElementById("id_station").value; 
    var new_station = document.getElementById("station_data1").value;



if ((!new_station)) {
    Swal.fire({
        width: 400,
        title: 'Please input informaion!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 1500
      });
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Station_Update.php",
        async: false,
        cache: false,
        data: {
          Emp : emp,
          ST_ID : st_id,
          New_Station : new_station

        },
    success: function(result){
        Swal.fire({
            width: 400,
            title: 'Update Successfully!',
            icon: 'success',
            showConfirmButton: false,
            timer: 1500
          });
        //modal close
        $('#EditstationModal').modal('hide');
        $('.modal-backdrop').remove(); 
        Load_Station(); 
    }  
});
}
}