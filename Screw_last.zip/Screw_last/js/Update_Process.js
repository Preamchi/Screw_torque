
function Send_ID(e) {
    document.getElementById("id_process").value = e;
    var process_id = e;


    $.ajax({
        type: "GET",
        url: "ajax/Nijiko_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Process_Id : process_id
        },

        success: function(result) {
            const myJson = JSON.parse(result);        
          document.getElementById("station_id").value = myJson.Station_Id; 
            document.getElementById("nijiko_data").value = myJson.Nijiko;
            document.getElementById("screw_data").value = myJson.Channel; 
            document.getElementById("seq").value = myJson.Sequence;
            document.getElementById("seq_before").value = myJson.Sequence_Before; 
            document.getElementById("torque").value = myJson.Torque; 
            document.getElementById("torquemax_data").value = myJson.Torque_Max;
            document.getElementById("torque_min").value = myJson.Torque_Min;  
    
        
        
        
          
           
        }
    });

   
}
 
function Nijiko_Value1() {
    $.ajax({
        url: "ajax/Nijiko_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
         
            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='nijiko_select' >";
            cartoptions += "<option>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Nijiko'];
                cartoptions += "<option value='" + id + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("nijiko_data").innerHTML = cartoptions;
            
        }
    });
}




function Update_Process() {
    var emp = document.getElementById('emp').value;
    var nijiko_id = document.getElementById("id_nijiko").value; 
    var new_nijiko = document.getElementById("nijiko_data").value;
    var new_station = document.getElementById("station").value;
    var new_screw = document.getElementById("screw").value; 


if ((!new_nijiko)) {
    Swal.fire({
        width: 400,
        title: 'Input Nijiko Name Please!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 2000,
      })
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Nijiko_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          Niji_ID: nijiko_id,
          Screw : new_screw,
          Station : new_station,
          Nijiko : new_nijiko
       
        },
        
        success: function(result) {
            Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              }); 
              $('#editnijikoModal').modal('hide');
              $('.modal-backdrop').remove();
              Load_Nijiko(); 
        }
    });
}
}  