
function login() {
    var username = document.getElementById('Username').value;
    var password = document.getElementById('PW').value;

    if ((!username) || (!password)) {
        alert('คุณกรอกข้อมูลไม่ครบ');
    } else {

        $.ajax({
            url: "ajax/Login.php",
            async: false,
            cache: false,
            data: {
                Name: username,
                Password: password
            },

            success: function(result) {
           /*      alert(result); */
                if (result == 'no'){
                    Swal.fire({
                        width: 400,
                        title: 'You don\'t have permission',
                        icon: 'warning',
                        showConfirmButton: false,
                        timer: 1500
                      })
                }else if (result == 'yes'){
                    Swal.fire({
                        width: 400,
                        title: 'Log In Success',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 1800
                      })
                        location.replace('Dashboad.php');
                 }else {
                    // alert(result);
                    Swal.fire({
                        width: 400,
                        title: result,
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1500
                    })
                 }
              

            }
        })
    }
}

function handleEnterKeyPress(event) {
    // Check if the key code is for the enter key (13)
    if (event.keyCode === 13) {
      event.preventDefault(); // Prevent form submission
      login(); // Call the login function
    }
  }
  
  // Add event listener to the login-form
  document.getElementById("login-form").addEventListener("keyup", handleEnterKeyPress);