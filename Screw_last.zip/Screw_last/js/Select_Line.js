function Line_value() {
    $.ajax({
        url: "ajax/Line_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
          options += "<option>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Line'];
               options += "<option value='" + id + "'>" +
                    name + "</option>";
            }
           options += '</select>';

            document.getElementById("line_loop").innerHTML = options;
            
        }
    });
}