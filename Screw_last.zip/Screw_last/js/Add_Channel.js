function Add_Channel() {
   
    var emp = document.getElementById('emp').value;
    var channel_name = document.getElementById('chname_input').value;
    var plc = document.getElementById('plc_input').value;
    var station = document.getElementById('station_loop').value;
    var select = document.getElementById("station_loop");
    var selectedOption = select.options[select.selectedIndex];
    var selectedId = selectedOption.id;
 
    console.log(channel_name, plc, station,emp);

    if ((!plc) || (!station)|| (!channel_name) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Channel_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp,  
                Channel_Name : channel_name,
                PLC : plc,
                station : station,
                Model:selectedId
              
            },
            success: function(result) {
                if(result == 'have_data'){
                    Swal.fire({
                        width: 400,
                        title: 'Add failed!',
                        text: 'User information already exists.',
                        icon: 'error',
                        showConfirmButton: false,
                        timer: 1500
                      });
                      document.getElementById("chname_input").value = '';
                      document.getElementById("plc_input").value = '';
                      
                }else{
                    Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1700
                  });

                  $('#addchannelModal').modal('hide');
                  $('.modal-backdrop').remove();
                $("#Addchannel").trigger("reset")
                  Load_Channel();
                }
               
     }
        });
    } 
} 
 /* alert(result);
                Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });
                  
                  $('#addchannelModal').modal('hide');
                  $('.modal-backdrop').remove();
                  Load_Channel(); */