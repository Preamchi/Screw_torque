function Add_Line() {
   
    var emp1 = document.getElementById('emp').value;
    var line_name = document.getElementById('linename_input').value;


    if ((!line_name) ) {
        Swal.fire({
            width: 400,
            title: 'Please input informaion!',
            icon: 'warning',
            showConfirmButton: false,
            timer: 1500
          });
    } else {
        $.ajax({
            type: "GET",
            url: "ajax/Line_Add.php",
            async: false,
            cache: false,
            data: {
                Emp: emp1,
               Line_name : line_name
      
            },
            success: function(result) {
if(result == 'have_data'){ 
    Swal.fire({
    width: 400,
    title: 'Add failed!',
    text: 'User information already exists.',
    icon: 'error',
    showConfirmButton: false,
    timer: 1700
  });
  document.getElementById("linename_input").value = '';
}else{
         Swal.fire({
                    width: 400,
                    title: 'Add Successfully!',
                    icon: 'success',
                    showConfirmButton: false,
                    timer: 1500
                  });

           $('#AddlineModal').modal('hide');
           $('.modal-backdrop').remove(); 
           $("#Addline").trigger("reset");
           Load_Line();
  }
           
     }
        });
        
    }
}
