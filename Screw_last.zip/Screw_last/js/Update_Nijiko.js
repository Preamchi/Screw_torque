
function send_id(e) {
    document.getElementById("id_hold_nijiko").value = e;
    var nijiko_id = e;


    $.ajax({
        type: "GET",
        url: "ajax/Nijiko_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Nijiko_ID : nijiko_id
        },

        success: function(result) {
            console.log(result);
            const myJson = JSON.parse(result);

           
            document.getElementById("N_name").value = myJson.Nijiko_Name;
            document.getElementById("last_part").value = myJson.Part_No; 
            document.getElementById("last_st").value = myJson.Station_Name;
        
          
           
        }
    });

   
}
 
function load_value1() {
    $.ajax({
        url: "ajax/Station_value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);

            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='station_newo' >";
            cartoptions += "<option>select new...</option>";

            for (let x in myJson) {

                var id = myJson[x]['ST_ID'];
                var name = myJson[x]['Station_Name'];
                cartoptions += "<option value='" + id + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("station_loop1").innerHTML = cartoptions;

        }
    });
}

function load_part1() {
    $.ajax({
        url: "ajax/Part_Value.php",
        async: false,
        cache: false,

        success: function(result) {
            var myJson = JSON.parse(result);

            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='part_newar' >";

            cartoptions += "<option>select new....</option>";
            for (let x in myJson) {

                var id = myJson[x]['Part_No'];
                cartoptions += "<option value='" + id + "'>" + id + "</option>";
            }
            cartoptions += '</select>';
            document.getElementById("partno_loop1").innerHTML = cartoptions;

        }
    });
}

function UpdateNijiko() {
    var emp = document.getElementById('emp').value;
    var last_id = document.getElementById("id_hold_nijiko").value; 
    var new_nijiko = document.getElementById("N_name").value;
    var new_partno = document.getElementById("partno_loop1").value;
    var new_station= document.getElementById("station_loop1").value; 
/* console.log(emp, new_partno, new_cartname,channel_id,new_channel); */


if ((!new_nijiko)  ) {
    alert('กรอกข้อมูลไม่ครบ');
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Nijiko_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          LastN_ID: last_id,
          New_PartNo : new_partno,
          New_Station : new_station,
          New_Nijiko : new_nijiko
       
        },
        
        success: function(result) {
        console.log(result);
        }
    });
    alert('Update successfully!!');
    load_all_view();
}
}  