
 function Send_id(e) {
    document.getElementById("id_hold_channel").value = e;
    var channel_id = e;

console.log(channel_id);
    $.ajax({
        type: "GET",
        url: "ajax/Channel_Editmodal.php",
        async: false,
        cache: false,
        data: {
            Channel_ID : channel_id
        },

        success: function(result) {
  
            const myJson = JSON.parse(result);

            document.getElementById("chname_data").value = myJson.Channel;
            document.getElementById("plc_data").value = myJson.PLC_REF;
            document.getElementById("station_data1").value = myJson.StationName; 
            document.getElementById("model_data1").value = myJson.Model;
            document.getElementById("model_id").value = myJson.Model_ID; 
            document.getElementById("station_id").value = myJson.ST_ID; 
        
          
           
        }
    });

   
}
 

function Model_value1() {
    var model = document.getElementById("model_id").value; 
    $.ajax({
        url: "ajax/Model_value.php",
        async: false,
        cache: false,

        success: function(result) {
  /*           console.log(result); */
          var myJson = JSON.parse(result);
         
            var cartoptions =
                "<select class='form-select' aria-label='Default select example' id='model_new1' >";
            cartoptions += "<option value='"+model+"'>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ID'];
                var name = myJson[x]['Model'];
                cartoptions += "<option value='" + name + "'>" +
                    name + "</option>";
            }
            cartoptions += '</select>';

            document.getElementById("model_loop1").innerHTML = cartoptions;
            var select = document.getElementById("model_loop1");
            var selectedOption = select.options[select.selectedIndex];
            var selectedId = selectedOption.id;
             
        }
    });
}

function Station_value1(e) {
    
    document.getElementById("model_loop1").value = e;
    var model = e;
    var station = document.getElementById("station_id").value; 

    $.ajax({
        url: "ajax/Station_Select.php",
        async: false,
        cache: false,
        data: {
         Model : model
          }, 
        success: function(result) {
        /*     console.log(result); */
            var myJson = JSON.parse(result);
         
            var options =
                "<select class='form-select' aria-label='Default select example' id='model_new' >";
           options += "<option value='"+station+"'>select....</option>";

            for (let x in myJson) {

                var id = myJson[x]['ST_ID'];
                var model_id = myJson[x]['Model_ID'];
                var name = myJson[x]['Station'];
               options += "<option value='" + id +"' id='"+model_id+"'>" + name +"</option>";
            }
            options += '</select>';
            document.getElementById("station_loop1").innerHTML = options;
    

        }   
    });
}
 

function Updatechannel() {
    var emp = document.getElementById('emp').value;
    var last_id = document.getElementById("id_hold_channel").value; 
    var channel = document.getElementById("chname_data").value;
    var plc = document.getElementById("plc_data").value;
    var station = document.getElementById("station_loop1").value;
    var model = document.getElementById("model_loop1").value; 


console.log(emp, station, model,last_id, channel,plc,selectedId);


if ((!channel) || (!plc) ) {
    Swal.fire({
        width: 400,
        title: 'Please input informaion!',
        icon: 'warning',
        showConfirmButton: false,
        timer: 1500
      });
} else {
    $.ajax({
        type: "GET",
        url: "ajax/Channel_Update.php",
        async: false,
        cache: false,
        data: {
          Emp: emp,
          LastCH_ID: last_id,
          CH : channel ,
          PLC : plc,
          Station : station,
          Last_Model: model,
          New_Model : selectedId
       
        },
        
        success: function(result) {
            Swal.fire({
                width: 400,
                title: 'Update Successfully!',
                icon: 'success',
                showConfirmButton: false,
                timer: 1500
              });
       
            $('#editchannelModal').modal('hide');
            $('.modal-backdrop').remove(); 
            Load_Channel(); 
        }
    });
 
}
}  