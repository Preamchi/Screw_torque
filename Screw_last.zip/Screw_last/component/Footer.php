<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">
                <li class="nav-item">
                </li>
            </ul>
        </nav>
        <div class="copyright m-auto">
            2023, made website by <b>MFD System of STTC</b>
            <img width="100" height="25" src="img/sonyinternal.png">
        </div>
    </div>
</footer>